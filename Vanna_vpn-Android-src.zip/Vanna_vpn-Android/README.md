# Vanna_vpn

Нативный Android VPN-клиент на Xray-core (аналог v2RayTun) с дизайном «жидкое стекло».

## Возможности
- Протоколы: **VLESS** (включая REALITY + Vision), **VMess**, **Trojan**, **Shadowsocks**
- Транспорты: TCP, WebSocket, gRPC, HTTPUpgrade, XHTTP
- **Подписки по ссылке**: вставь `https://…` — серверы добавятся автоматически; кнопка ⟳ обновляет все подписки
- Одиночные ссылки `vless://`, `vmess://`, `trojan://`, `ss://`
- Настоящий системный VPN через `VpnService` + TUN, трафик обрабатывает Xray-core
  (библиотека [AndroidLibXrayLite](https://github.com/2dust/AndroidLibXrayLite) v26.6.2)
- UI: Jetpack Compose, liquid glass (полупрозрачные панели, неоновые блики)

## Структура
```
app/src/main/java/com/glassvpn/app/
├── core/
│   ├── ServerProfile.kt        # модель сервера
│   ├── LinkParser.kt           # парсер ссылок и подписок (покрыт тестами)
│   ├── XrayConfigBuilder.kt    # генератор JSON-конфига Xray (покрыт тестами)
│   ├── Storage.kt              # хранение профилей/подписок
│   └── SubscriptionManager.kt  # загрузка и обновление подписок
├── service/
│   ├── XrayVpnService.kt       # VpnService: TUN + запуск Xray-core
│   └── VpnStateBus.kt          # состояние VPN для UI
└── ui/                         # Compose-интерфейс (liquid glass)
```

## Сборка
Нужны: JDK 17, Android SDK 34. `app/libs/libv2ray.aar` уже в комплекте.

```bash
echo "sdk.dir=/path/to/android-sdk" > local.properties
gradle :app:assembleDebug        # APK: app/build/outputs/apk/debug/app-debug.apk
gradle :app:testDebugUnitTest    # 20 юнит-тестов парсера и конфигов
```

## Как работает VPN
1. `VpnService.Builder` создаёт TUN (26.26.26.1/30, маршрут 0.0.0.0/0, DNS 1.1.1.1/8.8.8.8).
2. fd интерфейса передаётся в `CoreController.startLoop(config, tunFd)` — Xray-core
   читает пакеты напрямую через tun-inbound.
3. Собственный пакет приложения исключён из VPN (`addDisallowedApplication`),
   поэтому исходящие соединения ядра идут мимо туннеля без `protect()`.

## Статус тестирования
- ✅ 20 юнит-тестов: парсинг VLESS/VMess/Trojan/SS (+REALITY, ws, grpc, IPv6, base64-подписки), генерация конфигов Xray
- ✅ APK собирается и подписан (debug)
- ⚠️ Живой туннель нужно проверить на реальном устройстве с рабочим сервером —
  в сборочной среде нет Android-устройства и VPN-сервера

## Известные ограничения v1
- Нет per-app proxy, правил маршрутизации по доменам и замера пинга
- Debug-подпись: для публикации нужен release-keystore
