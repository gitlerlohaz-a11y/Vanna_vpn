# Keep gomobile-generated bindings for the Xray core
-keep class libv2ray.** { *; }
-keep class go.** { *; }
