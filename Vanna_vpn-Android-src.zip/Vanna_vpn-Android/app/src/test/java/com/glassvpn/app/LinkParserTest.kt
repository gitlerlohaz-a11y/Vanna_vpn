package com.glassvpn.app

import com.glassvpn.app.core.LinkParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Base64

class LinkParserTest {

    @Test
    fun `parses vless reality link`() {
        val link = "vless://b831381d-6324-4d53-ad4f-8cda48b30811@1.2.3.4:443" +
            "?encryption=none&flow=xtls-rprx-vision&security=reality&sni=www.microsoft.com" +
            "&fp=chrome&pbk=SbVKOEMjK0sIlbwg4akyBg5mL5KZwwB-ed4eEE7YnRc&sid=6ba85179&spx=%2F&type=tcp" +
            "#My%20Reality%20Server"
        val p = LinkParser.parseLink(link)
        assertEquals("vless", p.protocol)
        assertEquals("My Reality Server", p.name)
        assertEquals("1.2.3.4", p.address)
        assertEquals(443, p.port)
        assertEquals("b831381d-6324-4d53-ad4f-8cda48b30811", p.userId)
        assertEquals("xtls-rprx-vision", p.flow)
        assertEquals("reality", p.security)
        assertEquals("www.microsoft.com", p.sni)
        assertEquals("chrome", p.fingerprint)
        assertEquals("SbVKOEMjK0sIlbwg4akyBg5mL5KZwwB-ed4eEE7YnRc", p.publicKey)
        assertEquals("6ba85179", p.shortId)
        assertEquals("/", p.spiderX)
        assertEquals("tcp", p.network)
    }

    @Test
    fun `parses vless ws tls link`() {
        val link = "vless://uuid-here@example.com:443?type=ws&security=tls&sni=cdn.example.com" +
            "&host=cdn.example.com&path=%2Fwspath#WS%20Server"
        val p = LinkParser.parseLink(link)
        assertEquals("ws", p.network)
        assertEquals("tls", p.security)
        assertEquals("/wspath", p.path)
        assertEquals("cdn.example.com", p.host)
    }

    @Test
    fun `parses vmess base64 link`() {
        val json = """{"v":"2","ps":"Test VMess","add":"5.6.7.8","port":"8443","id":"a3482e88-686a-4a58-8126-99c9df64b7bf","aid":"0","scy":"auto","net":"ws","type":"none","host":"h.example.com","path":"/vm","tls":"tls","sni":"h.example.com"}"""
        val link = "vmess://" + Base64.getEncoder().encodeToString(json.toByteArray())
        val p = LinkParser.parseLink(link)
        assertEquals("vmess", p.protocol)
        assertEquals("Test VMess", p.name)
        assertEquals("5.6.7.8", p.address)
        assertEquals(8443, p.port)
        assertEquals("a3482e88-686a-4a58-8126-99c9df64b7bf", p.userId)
        assertEquals("ws", p.network)
        assertEquals("tls", p.security)
        assertEquals("/vm", p.path)
        assertEquals("h.example.com", p.sni)
    }

    @Test
    fun `parses trojan link`() {
        val link = "trojan://p%40ssw0rd@9.10.11.12:443?security=tls&sni=t.example.com&type=tcp#Trojan%20One"
        val p = LinkParser.parseLink(link)
        assertEquals("trojan", p.protocol)
        assertEquals("p@ssw0rd", p.userId)
        assertEquals("9.10.11.12", p.address)
        assertEquals("tls", p.security)
        assertEquals("t.example.com", p.sni)
        assertEquals("Trojan One", p.name)
    }

    @Test
    fun `parses ss sip002 link`() {
        val userInfo = Base64.getUrlEncoder().withoutPadding()
            .encodeToString("chacha20-ietf-poly1305:secretpass".toByteArray())
        val link = "ss://$userInfo@13.14.15.16:8388#SS%20Node"
        val p = LinkParser.parseLink(link)
        assertEquals("shadowsocks", p.protocol)
        assertEquals("chacha20-ietf-poly1305", p.cipher)
        assertEquals("secretpass", p.userId)
        assertEquals("13.14.15.16", p.address)
        assertEquals(8388, p.port)
        assertEquals("SS Node", p.name)
    }

    @Test
    fun `parses ss legacy link`() {
        val payload = Base64.getEncoder()
            .encodeToString("aes-256-gcm:pass123@17.18.19.20:9999".toByteArray())
        val p = LinkParser.parseLink("ss://$payload#Legacy")
        assertEquals("aes-256-gcm", p.cipher)
        assertEquals("pass123", p.userId)
        assertEquals("17.18.19.20", p.address)
        assertEquals(9999, p.port)
    }

    @Test
    fun `parses ss 2022 plain userinfo`() {
        val link = "ss://2022-blake3-aes-256-gcm:cGFzc3dvcmRwYXNzd29yZA%3D%3D@21.22.23.24:8388#SS2022"
        val p = LinkParser.parseLink(link)
        assertEquals("2022-blake3-aes-256-gcm", p.cipher)
        assertEquals("cGFzc3dvcmRwYXNzd29yZA==", p.userId)
    }

    @Test
    fun `parses ipv6 host`() {
        val link = "vless://uuid@[2001:db8::1]:443?type=tcp&security=none#V6"
        val p = LinkParser.parseLink(link)
        assertEquals("2001:db8::1", p.address)
        assertEquals(443, p.port)
    }

    @Test
    fun `parses base64 subscription with multiple links`() {
        val links = listOf(
            "vless://uuid1@1.1.1.1:443?type=tcp&security=tls&sni=a.com#Server1",
            "trojan://pw@2.2.2.2:443?security=tls#Server2",
            "ss://" + Base64.getUrlEncoder().withoutPadding()
                .encodeToString("aes-128-gcm:pw2".toByteArray()) + "@3.3.3.3:8388#Server3",
        ).joinToString("\n")
        val body = Base64.getEncoder().encodeToString(links.toByteArray())
        val profiles = LinkParser.parseSubscriptionContent(body, "https://sub.example.com/abc")
        assertEquals(3, profiles.size)
        assertEquals("Server1", profiles[0].name)
        assertEquals("trojan", profiles[1].protocol)
        assertEquals("shadowsocks", profiles[2].protocol)
        assertTrue(profiles.all { it.subscriptionUrl == "https://sub.example.com/abc" })
    }

    @Test
    fun `parses plain text subscription`() {
        val body = """
            vless://uuid@4.4.4.4:443?type=ws&security=tls&path=/x#PlainA

            trojan://pw@5.5.5.5:443#PlainB
        """.trimIndent()
        val profiles = LinkParser.parseSubscriptionContent(body)
        assertEquals(2, profiles.size)
    }

    @Test
    fun `skips malformed lines in subscription`() {
        val body = "vless://uuid@6.6.6.6:443?type=tcp#OK\nvmess://%%%broken%%%\nnot-a-link"
        val profiles = LinkParser.parseSubscriptionContent(body)
        assertEquals(1, profiles.size)
        assertEquals("OK", profiles[0].name)
    }
}
