package com.glassvpn.app

import com.glassvpn.app.core.RoutingOptions
import com.glassvpn.app.core.ServerProfile
import com.glassvpn.app.core.XrayConfigBuilder
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class XrayConfigBuilderTest {

    private fun parse(config: String): JsonObject = JsonParser.parseString(config).asJsonObject

    private val vlessReality = ServerProfile(
        name = "R", protocol = "vless", address = "1.2.3.4", port = 443,
        userId = "uuid-1", flow = "xtls-rprx-vision", network = "tcp",
        security = "reality", sni = "www.microsoft.com", fingerprint = "chrome",
        publicKey = "pbk123", shortId = "sid1", spiderX = "/",
    )

    @Test
    fun `tun config has tun inbound and routing`() {
        val root = parse(XrayConfigBuilder.build(vlessReality, forTun = true))
        val inbounds = root.getAsJsonArray("inbounds")
        assertEquals(1, inbounds.size())
        val tun = inbounds[0].asJsonObject
        assertEquals("tun", tun.get("protocol").asString)
        assertEquals(1500, tun.getAsJsonObject("settings").get("MTU").asInt)
        assertTrue(tun.getAsJsonObject("sniffing").get("enabled").asBoolean)

        val rules = root.getAsJsonObject("routing").getAsJsonArray("rules")
        assertTrue(rules.size() >= 1)
        assertEquals("direct", rules[0].asJsonObject.get("outboundTag").asString)
    }

    @Test
    fun `ping config has no inbounds`() {
        val root = parse(XrayConfigBuilder.build(vlessReality, forTun = false))
        assertEquals(0, root.getAsJsonArray("inbounds").size())
    }

    @Test
    fun `ping config has no geoip routing rules`() {
        val root = parse(XrayConfigBuilder.build(vlessReality, forTun = false))
        assertEquals(0, root.getAsJsonObject("routing").getAsJsonArray("rules").size())
    }

    @Test
    fun `global mode has no routing rules`() {
        val opts = RoutingOptions(mode = RoutingOptions.MODE_GLOBAL)
        val root = parse(XrayConfigBuilder.build(vlessReality, forTun = true, routing = opts))
        assertEquals(0, root.getAsJsonObject("routing").getAsJsonArray("rules").size())
    }

    @Test
    fun `bypass ru mode routes russian ips and domains direct`() {
        val opts = RoutingOptions(mode = RoutingOptions.MODE_BYPASS_RU)
        val root = parse(XrayConfigBuilder.build(vlessReality, forTun = true, routing = opts))
        val rules = root.getAsJsonObject("routing").getAsJsonArray("rules")
        assertEquals(2, rules.size())
        val ipRule = rules[0].asJsonObject
        assertEquals("direct", ipRule.get("outboundTag").asString)
        assertTrue(ipRule.getAsJsonArray("ip").toString().contains("geoip:ru"))
        val domainRule = rules[1].asJsonObject
        assertTrue(domainRule.getAsJsonArray("domain").toString().contains("domain:ru"))
    }

    @Test
    fun `custom rules split into ip and domain criteria`() {
        val opts = RoutingOptions(
            mode = RoutingOptions.MODE_BYPASS_LAN,
            directRules = listOf("example.com", "1.2.3.4", "10.0.0.0/8", "geosite:category-ads-all"),
            blockRules = listOf("ads.evil.com"),
        )
        val root = parse(XrayConfigBuilder.build(vlessReality, forTun = true, routing = opts))
        val rules = root.getAsJsonObject("routing").getAsJsonArray("rules")
        assertEquals(3, rules.size()) // block, direct, bypass-lan

        val block = rules[0].asJsonObject
        assertEquals("block", block.get("outboundTag").asString)
        assertTrue(block.getAsJsonArray("domain").toString().contains("domain:ads.evil.com"))

        val direct = rules[1].asJsonObject
        assertEquals("direct", direct.get("outboundTag").asString)
        val ips = direct.getAsJsonArray("ip").toString()
        val domains = direct.getAsJsonArray("domain").toString()
        assertTrue(ips.contains("1.2.3.4"))
        assertTrue(ips.contains("10.0.0.0/8"))
        assertTrue(domains.contains("domain:example.com"))
        assertTrue(domains.contains("geosite:category-ads-all"))

        assertTrue(rules[2].asJsonObject.getAsJsonArray("ip").toString().contains("geoip:private"))
    }

    @Test
    fun `ip detection distinguishes ips from domains`() {
        assertTrue(XrayConfigBuilder.isIpOrCidr("192.168.1.1"))
        assertTrue(XrayConfigBuilder.isIpOrCidr("10.0.0.0/8"))
        assertTrue(XrayConfigBuilder.isIpOrCidr("2001:db8::1"))
        assertEquals(false, XrayConfigBuilder.isIpOrCidr("example.com"))
        assertEquals(false, XrayConfigBuilder.isIpOrCidr("1.2.3.4.com"))
    }

    @Test
    fun `vless reality outbound is correct`() {
        val root = parse(XrayConfigBuilder.build(vlessReality))
        val proxy = root.getAsJsonArray("outbounds")[0].asJsonObject
        assertEquals("vless", proxy.get("protocol").asString)

        val vnext = proxy.getAsJsonObject("settings").getAsJsonArray("vnext")[0].asJsonObject
        assertEquals("1.2.3.4", vnext.get("address").asString)
        assertEquals(443, vnext.get("port").asInt)
        val user = vnext.getAsJsonArray("users")[0].asJsonObject
        assertEquals("uuid-1", user.get("id").asString)
        assertEquals("none", user.get("encryption").asString)
        assertEquals("xtls-rprx-vision", user.get("flow").asString)

        val stream = proxy.getAsJsonObject("streamSettings")
        assertEquals("reality", stream.get("security").asString)
        val reality = stream.getAsJsonObject("realitySettings")
        assertEquals("www.microsoft.com", reality.get("serverName").asString)
        assertEquals("pbk123", reality.get("publicKey").asString)
        assertEquals("sid1", reality.get("shortId").asString)
        assertEquals("chrome", reality.get("fingerprint").asString)
    }

    @Test
    fun `vmess ws tls outbound is correct`() {
        val p = ServerProfile(
            name = "V", protocol = "vmess", address = "h.example.com", port = 8443,
            userId = "uuid-2", cipher = "auto", network = "ws", security = "tls",
            sni = "h.example.com", host = "h.example.com", path = "/vm",
        )
        val proxy = parse(XrayConfigBuilder.build(p)).getAsJsonArray("outbounds")[0].asJsonObject
        assertEquals("vmess", proxy.get("protocol").asString)
        val user = proxy.getAsJsonObject("settings").getAsJsonArray("vnext")[0]
            .asJsonObject.getAsJsonArray("users")[0].asJsonObject
        assertEquals(0, user.get("alterId").asInt)
        assertEquals("auto", user.get("security").asString)

        val stream = proxy.getAsJsonObject("streamSettings")
        assertEquals("ws", stream.get("network").asString)
        assertEquals("/vm", stream.getAsJsonObject("wsSettings").get("path").asString)
        assertEquals("tls", stream.get("security").asString)
        assertEquals("h.example.com", stream.getAsJsonObject("tlsSettings").get("serverName").asString)
    }

    @Test
    fun `trojan outbound is correct`() {
        val p = ServerProfile(
            name = "T", protocol = "trojan", address = "9.9.9.9", port = 443,
            userId = "pw", security = "tls", sni = "t.example.com",
        )
        val proxy = parse(XrayConfigBuilder.build(p)).getAsJsonArray("outbounds")[0].asJsonObject
        val server = proxy.getAsJsonObject("settings").getAsJsonArray("servers")[0].asJsonObject
        assertEquals("pw", server.get("password").asString)
        assertEquals("t.example.com",
            proxy.getAsJsonObject("streamSettings").getAsJsonObject("tlsSettings").get("serverName").asString)
    }

    @Test
    fun `shadowsocks outbound is correct`() {
        val p = ServerProfile(
            name = "S", protocol = "shadowsocks", address = "8.8.4.4", port = 8388,
            userId = "sspass", cipher = "chacha20-ietf-poly1305",
        )
        val proxy = parse(XrayConfigBuilder.build(p)).getAsJsonArray("outbounds")[0].asJsonObject
        val server = proxy.getAsJsonObject("settings").getAsJsonArray("servers")[0].asJsonObject
        assertEquals("chacha20-ietf-poly1305", server.get("method").asString)
        assertEquals("sspass", server.get("password").asString)
        assertEquals("none", proxy.getAsJsonObject("streamSettings").get("security").asString)
    }

    @Test
    fun `grpc stream settings`() {
        val p = vlessReality.copy(network = "grpc", serviceName = "svc", mode = "multi")
        val stream = parse(XrayConfigBuilder.build(p)).getAsJsonArray("outbounds")[0]
            .asJsonObject.getAsJsonObject("streamSettings")
        assertEquals("grpc", stream.get("network").asString)
        val grpc = stream.getAsJsonObject("grpcSettings")
        assertEquals("svc", grpc.get("serviceName").asString)
        assertTrue(grpc.get("multiMode").asBoolean)
    }

    @Test
    fun `outbounds always include direct and block`() {
        val outbounds = parse(XrayConfigBuilder.build(vlessReality)).getAsJsonArray("outbounds")
        assertEquals(3, outbounds.size())
        assertEquals("freedom", outbounds[1].asJsonObject.get("protocol").asString)
        assertEquals("blackhole", outbounds[2].asJsonObject.get("protocol").asString)
    }

    @Test
    fun `tls sni falls back to address`() {
        val p = ServerProfile(
            name = "F", protocol = "trojan", address = "fallback.example.com", port = 443,
            userId = "pw", security = "tls",
        )
        val tls = parse(XrayConfigBuilder.build(p)).getAsJsonArray("outbounds")[0]
            .asJsonObject.getAsJsonObject("streamSettings").getAsJsonObject("tlsSettings")
        assertEquals("fallback.example.com", tls.get("serverName").asString)
        assertFalse(tls.get("allowInsecure").asBoolean)
    }
}
