package com.glassvpn.app.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

sealed class VpnState {
    data object Disconnected : VpnState()
    data object Connecting : VpnState()
    data class Connected(val serverName: String, val proxyOnly: Boolean = false) : VpnState()
    data class Error(val message: String) : VpnState()
}

/** In-process state bus between the VPN service and the UI. */
object VpnStateBus {
    private val _state = MutableStateFlow<VpnState>(VpnState.Disconnected)
    val state: StateFlow<VpnState> = _state

    fun update(state: VpnState) {
        _state.value = state
    }
}
