package com.glassvpn.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.glassvpn.app.ui.theme.BlobAlpha
import com.glassvpn.app.ui.theme.DeepSpace
import com.glassvpn.app.ui.theme.GlassBorderBottom
import com.glassvpn.app.ui.theme.GlassBorderTop
import com.glassvpn.app.ui.theme.GlassWhite
import com.glassvpn.app.ui.theme.MidnightBlue
import com.glassvpn.app.ui.theme.NeonCyan
import com.glassvpn.app.ui.theme.NeonMint
import com.glassvpn.app.ui.theme.NeonViolet

/** Full-screen dark gradient with soft neon "light blobs" behind the glass panels. */
@Composable
fun LiquidBackground(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DeepSpace, MidnightBlue, DeepSpace)))
    ) {
        GlowBlob(color = NeonViolet.copy(alpha = 0.35f * BlobAlpha), size = 420.dp, offset = Offset(-0.25f, -0.15f))
        GlowBlob(color = NeonCyan.copy(alpha = 0.22f * BlobAlpha), size = 380.dp, offset = Offset(0.85f, 0.25f))
        GlowBlob(color = NeonMint.copy(alpha = 0.16f * BlobAlpha), size = 360.dp, offset = Offset(0.15f, 0.95f))
        content()
    }
}

@Composable
private fun GlowBlob(color: Color, size: Dp, offset: Offset) {
    Box(
        modifier = Modifier
            .fillMaxSize(),
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .align(androidx.compose.ui.BiasAlignment(offset.x * 2 - 1, offset.y * 2 - 1))
                .background(
                    Brush.radialGradient(
                        colors = listOf(color, Color.Transparent),
                    )
                )
        )
    }
}

/** Translucent rounded panel with a top-light border — the "liquid glass" card. */
fun Modifier.glass(cornerRadius: Dp = 24.dp, fill: Color = GlassWhite): Modifier =
    this
        .clip(RoundedCornerShape(cornerRadius))
        .background(
            Brush.verticalGradient(
                listOf(fill.copy(alpha = fill.alpha + 0.04f), fill)
            )
        )
        .border(
            width = 1.dp,
            brush = Brush.verticalGradient(listOf(GlassBorderTop, GlassBorderBottom)),
            shape = RoundedCornerShape(cornerRadius),
        )
