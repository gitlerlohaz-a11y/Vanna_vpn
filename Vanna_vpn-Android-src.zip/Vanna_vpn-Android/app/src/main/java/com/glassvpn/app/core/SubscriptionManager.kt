package com.glassvpn.app.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/** Fetches subscription URLs and keeps stored profiles in sync. */
object SubscriptionManager {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    /** Downloads and parses a subscription. Returns parsed profiles (may be empty). */
    suspend fun fetch(url: String): List<ServerProfile> = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "GlassVPN/1.0")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("HTTP ${response.code}")
            val body = response.body?.string() ?: error("Empty body")
            LinkParser.parseSubscriptionContent(body, subscriptionUrl = url)
        }
    }

    /** Adds a new subscription: fetches it, stores profiles and the subscription record. */
    suspend fun add(url: String): Int {
        val profiles = fetch(url)
        if (profiles.isEmpty()) error("В подписке не найдено серверов")
        Storage.replaceSubscriptionProfiles(url, profiles)
        val subs = Storage.subscriptions.filterNot { it.url == url }
        Storage.subscriptions = subs + Subscription(url = url, lastUpdated = System.currentTimeMillis())
        return profiles.size
    }

    /** Refreshes all stored subscriptions. Returns total fetched profile count. */
    suspend fun refreshAll(): Int {
        var total = 0
        val updated = Storage.subscriptions.map { sub ->
            runCatching { fetch(sub.url) }.getOrNull()?.let { fresh ->
                if (fresh.isNotEmpty()) {
                    Storage.replaceSubscriptionProfiles(sub.url, fresh)
                    total += fresh.size
                    sub.copy(lastUpdated = System.currentTimeMillis())
                } else sub
            } ?: sub
        }
        Storage.subscriptions = updated
        return total
    }
}
