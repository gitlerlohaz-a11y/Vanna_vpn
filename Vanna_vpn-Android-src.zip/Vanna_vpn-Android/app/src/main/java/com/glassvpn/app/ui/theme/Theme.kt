package com.glassvpn.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color

enum class ThemeMode { DARK, LIGHT }

/** Full color palette for one theme. */
data class GlassPalette(
    val bgTop: Color,
    val bgMid: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val glassFill: Color,
    val glassBorderTop: Color,
    val glassBorderBottom: Color,
    val orbInner: Color,
    val dialogFill: Color,
    val cardSelectedFill: Color,
    val badgeFill: Color,
    val fieldBorder: Color,
    val blobAlpha: Float,
)

// Neon accents shared by both themes
val NeonViolet = Color(0xFF7C5CFF)
val NeonCyan = Color(0xFF38E1FF)
val NeonMint = Color(0xFF4AF0C0)
val DangerRed = Color(0xFFFF5C7A)

private val DarkPalette = GlassPalette(
    bgTop = Color(0xFF0A0E1A),
    bgMid = Color(0xFF111A33),
    textPrimary = Color(0xFFF2F5FF),
    textSecondary = Color(0x99F2F5FF),
    glassFill = Color(0x14FFFFFF),
    glassBorderTop = Color(0x40FFFFFF),
    glassBorderBottom = Color(0x0DFFFFFF),
    orbInner = Color(0xFF0D1326),
    dialogFill = Color(0xE6121A30),
    cardSelectedFill = Color(0x2238E1FF),
    badgeFill = Color(0x267C5CFF),
    fieldBorder = Color(0x33FFFFFF),
    blobAlpha = 1f,
)

private val LightPalette = GlassPalette(
    bgTop = Color(0xFFEef3FC),
    bgMid = Color(0xFFDCE6F7),
    textPrimary = Color(0xFF16203A),
    textSecondary = Color(0x9916203A),
    glassFill = Color(0x8CFFFFFF),
    glassBorderTop = Color(0xCCFFFFFF),
    glassBorderBottom = Color(0x33FFFFFF),
    orbInner = Color(0xFFF4F8FF),
    dialogFill = Color(0xF5FFFFFF),
    cardSelectedFill = Color(0x4D38E1FF),
    badgeFill = Color(0x337C5CFF),
    fieldBorder = Color(0x3316203A),
    blobAlpha = 0.45f,
)

/** Snapshot-backed current palette: changing it recomposes everything that reads the getters below. */
val CurrentPalette = mutableStateOf(DarkPalette)

fun paletteFor(mode: ThemeMode): GlassPalette =
    if (mode == ThemeMode.LIGHT) LightPalette else DarkPalette

// Backwards-compatible accessors used across the UI
val DeepSpace: Color get() = CurrentPalette.value.bgTop
val MidnightBlue: Color get() = CurrentPalette.value.bgMid
val TextPrimary: Color get() = CurrentPalette.value.textPrimary
val TextSecondary: Color get() = CurrentPalette.value.textSecondary
val GlassWhite: Color get() = CurrentPalette.value.glassFill
val GlassBorderTop: Color get() = CurrentPalette.value.glassBorderTop
val GlassBorderBottom: Color get() = CurrentPalette.value.glassBorderBottom
val OrbInner: Color get() = CurrentPalette.value.orbInner
val DialogFill: Color get() = CurrentPalette.value.dialogFill
val CardSelectedFill: Color get() = CurrentPalette.value.cardSelectedFill
val BadgeFill: Color get() = CurrentPalette.value.badgeFill
val FieldBorder: Color get() = CurrentPalette.value.fieldBorder
val BlobAlpha: Float get() = CurrentPalette.value.blobAlpha

private val DarkScheme = darkColorScheme(
    primary = NeonViolet,
    secondary = NeonCyan,
    tertiary = NeonMint,
    background = DarkPalette.bgTop,
    surface = DarkPalette.bgMid,
    onPrimary = DarkPalette.textPrimary,
    onBackground = DarkPalette.textPrimary,
    onSurface = DarkPalette.textPrimary,
    error = DangerRed,
)

private val LightScheme = lightColorScheme(
    primary = NeonViolet,
    secondary = NeonCyan,
    tertiary = NeonMint,
    background = LightPalette.bgTop,
    surface = LightPalette.bgMid,
    onPrimary = Color.White,
    onBackground = LightPalette.textPrimary,
    onSurface = LightPalette.textPrimary,
    error = DangerRed,
)

@Composable
fun GlassVpnTheme(mode: ThemeMode = ThemeMode.DARK, content: @Composable () -> Unit) {
    CurrentPalette.value = paletteFor(mode)
    MaterialTheme(
        colorScheme = if (mode == ThemeMode.LIGHT) LightScheme else DarkScheme,
        content = content,
    )
}
