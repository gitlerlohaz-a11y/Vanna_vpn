package com.glassvpn.app.core

import java.util.UUID

/**
 * A single proxy server profile, normalized across protocols.
 * [userId] holds the VLESS/VMess UUID, the Trojan password or the Shadowsocks password.
 */
data class ServerProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val protocol: String,            // vless | vmess | trojan | shadowsocks
    val address: String,
    val port: Int,
    val userId: String = "",
    val alterId: Int = 0,
    val cipher: String = "auto",     // vmess security / shadowsocks method
    val flow: String = "",
    val network: String = "tcp",     // tcp | ws | grpc | httpupgrade | xhttp
    val security: String = "none",   // none | tls | reality
    val sni: String = "",
    val fingerprint: String = "",
    val alpn: String = "",
    val publicKey: String = "",      // REALITY pbk
    val shortId: String = "",        // REALITY sid
    val spiderX: String = "",        // REALITY spx
    val host: String = "",
    val path: String = "",
    val serviceName: String = "",    // gRPC
    val mode: String = "",           // gRPC multi / xhttp mode
    val headerType: String = "",     // tcp http header obfuscation
    val allowInsecure: Boolean = false,
    val subscriptionUrl: String = "",
) {
    val displayProtocol: String
        get() = when (protocol) {
            "shadowsocks" -> "SS"
            else -> protocol.uppercase()
        }
}
