package com.glassvpn.app.core

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.net.URI
import java.net.URLDecoder
import java.util.Base64

/**
 * Parses share links (vless:// vmess:// trojan:// ss://) and full subscription payloads
 * into [ServerProfile]s. Pure JVM code — covered by unit tests.
 */
object LinkParser {

    private val SCHEMES = listOf("vless://", "vmess://", "trojan://", "ss://")

    /** Parses the raw body of a subscription (base64 or plain text, one link per line). */
    fun parseSubscriptionContent(body: String, subscriptionUrl: String = ""): List<ServerProfile> {
        val text = decodeBase64Flexible(body.trim()) ?: body
        return text.lines()
            .map { it.trim() }
            .filter { line -> SCHEMES.any { line.startsWith(it, ignoreCase = true) } }
            .mapNotNull { runCatching { parseLink(it) }.getOrNull() }
            .map { it.copy(subscriptionUrl = subscriptionUrl) }
    }

    /** Parses a single share link. Throws on malformed input. */
    fun parseLink(link: String): ServerProfile {
        val trimmed = link.trim()
        return when {
            trimmed.startsWith("vless://", true) -> parseVless(trimmed)
            trimmed.startsWith("vmess://", true) -> parseVmess(trimmed)
            trimmed.startsWith("trojan://", true) -> parseTrojan(trimmed)
            trimmed.startsWith("ss://", true) -> parseShadowsocks(trimmed)
            else -> throw IllegalArgumentException("Unsupported link: ${trimmed.take(16)}")
        }
    }

    // ---------- VLESS ----------

    private fun parseVless(link: String): ServerProfile {
        val uri = URI(link)
        val q = parseQuery(uri.rawQuery)
        val security = q["security"] ?: "none"
        return ServerProfile(
            name = fragmentName(uri, "VLESS ${uri.host}"),
            protocol = "vless",
            address = stripBrackets(uri.host ?: error("no host")),
            port = uri.port.takeIf { it > 0 } ?: 443,
            userId = uri.userInfo ?: error("no uuid"),
            flow = q["flow"] ?: "",
            network = normalizeNetwork(q["type"]),
            security = security,
            sni = q["sni"] ?: "",
            fingerprint = q["fp"] ?: "",
            alpn = q["alpn"] ?: "",
            publicKey = q["pbk"] ?: "",
            shortId = q["sid"] ?: "",
            spiderX = q["spx"] ?: "",
            host = q["host"] ?: "",
            path = q["path"] ?: "",
            serviceName = q["serviceName"] ?: "",
            mode = q["mode"] ?: "",
            headerType = q["headerType"] ?: "",
            allowInsecure = q["allowInsecure"] == "1" || q["allowInsecure"] == "true",
        )
    }

    // ---------- VMess ----------

    private fun parseVmess(link: String): ServerProfile {
        val payload = link.substring("vmess://".length)
        val json = decodeBase64Flexible(payload)
            ?: throw IllegalArgumentException("vmess: not base64")
        val o: JsonObject = JsonParser.parseString(json).asJsonObject
        fun s(key: String): String = o.get(key)?.takeIf { !it.isJsonNull }?.asString.orEmpty()

        val tls = s("tls")
        return ServerProfile(
            name = s("ps").ifBlank { "VMess ${s("add")}" },
            protocol = "vmess",
            address = s("add"),
            port = s("port").toIntOrNull() ?: 443,
            userId = s("id"),
            alterId = s("aid").toIntOrNull() ?: 0,
            cipher = s("scy").ifBlank { "auto" },
            network = normalizeNetwork(s("net")),
            security = if (tls == "tls" || tls == "reality") tls else "none",
            sni = s("sni"),
            fingerprint = s("fp"),
            alpn = s("alpn"),
            host = s("host"),
            path = s("path"),
            serviceName = if (normalizeNetwork(s("net")) == "grpc") s("path") else "",
            headerType = s("type").takeIf { it != "none" }.orEmpty(),
        )
    }

    // ---------- Trojan ----------

    private fun parseTrojan(link: String): ServerProfile {
        val uri = URI(link)
        val q = parseQuery(uri.rawQuery)
        return ServerProfile(
            name = fragmentName(uri, "Trojan ${uri.host}"),
            protocol = "trojan",
            address = stripBrackets(uri.host ?: error("no host")),
            port = uri.port.takeIf { it > 0 } ?: 443,
            userId = urlDecode(uri.rawUserInfo ?: error("no password")),
            network = normalizeNetwork(q["type"]),
            security = q["security"] ?: "tls",
            sni = q["sni"] ?: "",
            fingerprint = q["fp"] ?: "",
            alpn = q["alpn"] ?: "",
            publicKey = q["pbk"] ?: "",
            shortId = q["sid"] ?: "",
            host = q["host"] ?: "",
            path = q["path"] ?: "",
            serviceName = q["serviceName"] ?: "",
            allowInsecure = q["allowInsecure"] == "1" || q["allowInsecure"] == "true",
        )
    }

    // ---------- Shadowsocks ----------

    private fun parseShadowsocks(link: String): ServerProfile {
        var body = link.substring("ss://".length)
        var name = ""
        val hashIdx = body.indexOf('#')
        if (hashIdx >= 0) {
            name = urlDecode(body.substring(hashIdx + 1))
            body = body.substring(0, hashIdx)
        }
        // drop plugin and other query params (unsupported in v1)
        val qIdx = body.indexOf('?')
        if (qIdx >= 0) body = body.substring(0, qIdx)

        val method: String
        val password: String
        val address: String
        val port: Int

        val atIdx = body.lastIndexOf('@')
        if (atIdx >= 0) {
            // SIP002: userinfo@host:port, userinfo is base64(method:pass) or plain method:pass
            val userInfoRaw = body.substring(0, atIdx)
            val hostPort = body.substring(atIdx + 1)
            val userInfo = decodeBase64Flexible(userInfoRaw)
                ?: urlDecode(userInfoRaw)
            val colon = userInfo.indexOf(':')
            require(colon > 0) { "ss: bad userinfo" }
            method = userInfo.substring(0, colon)
            password = userInfo.substring(colon + 1)
            val (h, p) = splitHostPort(hostPort)
            address = h; port = p
        } else {
            // Legacy: base64(method:pass@host:port)
            val decoded = decodeBase64Flexible(body)
                ?: throw IllegalArgumentException("ss: not base64")
            val at = decoded.lastIndexOf('@')
            require(at > 0) { "ss: bad legacy format" }
            val colon = decoded.indexOf(':')
            method = decoded.substring(0, colon)
            password = decoded.substring(colon + 1, at)
            val (h, p) = splitHostPort(decoded.substring(at + 1))
            address = h; port = p
        }

        return ServerProfile(
            name = name.ifBlank { "SS $address" },
            protocol = "shadowsocks",
            address = address,
            port = port,
            userId = password,
            cipher = method,
        )
    }

    // ---------- helpers ----------

    private fun normalizeNetwork(net: String?): String = when (net?.lowercase()) {
        null, "", "tcp", "raw" -> "tcp"
        "ws", "websocket" -> "ws"
        "grpc", "gun" -> "grpc"
        "httpupgrade" -> "httpupgrade"
        "xhttp", "splithttp" -> "xhttp"
        "h2", "http" -> "xhttp" // legacy h2 mapped to xhttp-compatible transport
        else -> "tcp"
    }

    private fun fragmentName(uri: URI, fallback: String): String {
        val frag = uri.rawFragment ?: return fallback
        return urlDecode(frag).ifBlank { fallback }
    }

    private fun splitHostPort(hostPort: String): Pair<String, Int> {
        val s = hostPort.trim().removeSuffix("/")
        if (s.startsWith("[")) { // IPv6
            val end = s.indexOf(']')
            require(end > 0) { "bad ipv6" }
            val host = s.substring(1, end)
            val port = s.substring(end + 1).removePrefix(":").toInt()
            return host to port
        }
        val colon = s.lastIndexOf(':')
        require(colon > 0) { "bad host:port" }
        return s.substring(0, colon) to s.substring(colon + 1).toInt()
    }

    private fun stripBrackets(host: String) = host.removePrefix("[").removeSuffix("]")

    private fun urlDecode(s: String): String =
        runCatching { URLDecoder.decode(s, "UTF-8") }.getOrDefault(s)

    private fun parseQuery(rawQuery: String?): Map<String, String> {
        if (rawQuery.isNullOrBlank()) return emptyMap()
        return rawQuery.split('&').mapNotNull { pair ->
            val idx = pair.indexOf('=')
            if (idx <= 0) null
            else pair.substring(0, idx) to urlDecode(pair.substring(idx + 1))
        }.toMap()
    }

    /**
     * Decodes standard or URL-safe base64 with or without padding.
     * Returns null if the input is not valid base64 or decodes to non-text garbage.
     */
    fun decodeBase64Flexible(input: String): String? {
        val cleaned = input.replace("\n", "").replace("\r", "").replace(" ", "").trim()
        if (cleaned.isEmpty()) return null
        val candidates = listOf(
            { Base64.getDecoder().decode(padded(cleaned)) },
            { Base64.getUrlDecoder().decode(padded(cleaned)) },
        )
        for (decode in candidates) {
            val bytes = runCatching(decode).getOrNull() ?: continue
            val text = String(bytes, Charsets.UTF_8)
            if (text.none { it == '\uFFFD' }) return text
        }
        return null
    }

    private fun padded(s: String): String {
        val rem = s.length % 4
        return if (rem == 0) s else s + "=".repeat(4 - rem)
    }
}
