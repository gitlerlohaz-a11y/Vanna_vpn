package com.glassvpn.app.core

import android.content.Context
import com.glassvpn.app.service.XrayVpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import libv2ray.Libv2ray

/**
 * Real delay measurement through the Xray core (HTTP request via the outbound),
 * same approach as v2rayNG — not a bare ICMP ping.
 */
object PingManager {

    private const val TEST_URL = "https://www.gstatic.com/generate_204"
    private const val TIMEOUT_MS = 12_000L
    private val semaphore = Semaphore(4) // limit parallel core instances

    /** Returns latency in ms, or -1 when the server is unreachable. */
    suspend fun measure(context: Context, profile: ServerProfile): Long =
        withContext(Dispatchers.IO) {
            XrayVpnService.initCoreEnv(context)
            semaphore.withPermit {
                runCatching {
                    withTimeout(TIMEOUT_MS) {
                        val config = XrayConfigBuilder.build(profile, forTun = false)
                        Libv2ray.measureOutboundDelay(config, TEST_URL)
                    }
                }.getOrDefault(-1L)
            }
        }
}
