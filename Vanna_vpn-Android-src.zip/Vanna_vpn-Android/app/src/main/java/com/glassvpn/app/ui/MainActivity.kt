package com.glassvpn.app.ui

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.glassvpn.app.core.LinkParser
import com.glassvpn.app.core.PingManager
import com.glassvpn.app.core.RoutingOptions
import com.glassvpn.app.core.ServerProfile
import com.glassvpn.app.core.Storage
import com.glassvpn.app.core.SubscriptionManager
import com.glassvpn.app.service.VpnState
import com.glassvpn.app.service.VpnStateBus
import com.glassvpn.app.service.XrayVpnService
import com.glassvpn.app.ui.theme.BadgeFill
import com.glassvpn.app.ui.theme.CardSelectedFill
import com.glassvpn.app.ui.theme.DangerRed
import com.glassvpn.app.ui.theme.DialogFill
import com.glassvpn.app.ui.theme.FieldBorder
import com.glassvpn.app.ui.theme.GlassVpnTheme
import com.glassvpn.app.ui.theme.GlassWhite
import com.glassvpn.app.ui.theme.NeonCyan
import com.glassvpn.app.ui.theme.NeonMint
import com.glassvpn.app.ui.theme.NeonViolet
import com.glassvpn.app.ui.theme.OrbInner
import com.glassvpn.app.ui.theme.TextPrimary
import com.glassvpn.app.ui.theme.TextSecondary
import com.glassvpn.app.ui.theme.ThemeMode
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val vpnPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) startVpnService()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var themeMode by remember {
                mutableStateOf(runCatching { ThemeMode.valueOf(Storage.themeMode) }.getOrDefault(ThemeMode.DARK))
            }
            val view = androidx.compose.ui.platform.LocalView.current
            LaunchedEffect(themeMode) {
                androidx.core.view.WindowCompat.getInsetsController(window, view)
                    .isAppearanceLightStatusBars = themeMode == ThemeMode.LIGHT
            }
            GlassVpnTheme(mode = themeMode) {
                MainScreen(
                    onConnect = { requestVpnAndStart() },
                    onDisconnect = { stopVpnService() },
                    themeMode = themeMode,
                    onThemeChange = { mode ->
                        themeMode = mode
                        Storage.themeMode = mode.name
                    },
                )
            }
        }
    }

    private fun requestVpnAndStart() {
        if (Storage.connectionMode == XrayVpnService.MODE_PROXY) {
            // proxy-only mode runs without the VPN consent dialog
            startVpnService()
            return
        }
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            vpnPermissionLauncher.launch(prepareIntent)
        } else {
            startVpnService()
        }
    }

    private fun startVpnService() {
        val intent = Intent(this, XrayVpnService::class.java).setAction(XrayVpnService.ACTION_CONNECT)
        startForegroundService(intent)
    }

    private fun stopVpnService() {
        val intent = Intent(this, XrayVpnService::class.java).setAction(XrayVpnService.ACTION_DISCONNECT)
        startService(intent)
    }
}

@Composable
fun MainScreen(
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    themeMode: ThemeMode,
    onThemeChange: (ThemeMode) -> Unit,
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val vpnState by VpnStateBus.state.collectAsStateWithLifecycle()
    var profiles by remember { mutableStateOf(Storage.profiles) }
    var selectedId by remember { mutableStateOf(Storage.selectedProfileId) }
    var showAddDialog by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var pings by remember { mutableStateOf(mapOf<String, Long>()) }
    var pinging by remember { mutableStateOf(false) }
    var connMode by remember { mutableStateOf(Storage.connectionMode) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(vpnState) {
        if (vpnState is VpnState.Error) {
            statusMessage = (vpnState as VpnState.Error).message
        }
    }

    LiquidBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 20.dp),
        ) {
            Spacer(Modifier.height(8.dp))
            TopBar(
                onAdd = { showAddDialog = true },
                onRefresh = {
                    scope.launch {
                        statusMessage = "Обновляю подписки…"
                        statusMessage = runCatching { SubscriptionManager.refreshAll() }
                            .fold(
                                onSuccess = { "Обновлено серверов: $it" },
                                onFailure = { "Ошибка обновления: ${it.message}" },
                            )
                        profiles = Storage.profiles
                        selectedId = Storage.selectedProfileId
                    }
                },
                onSettings = { showSettings = true },
            )

            Spacer(Modifier.height(24.dp))

            ConnectOrb(
                state = vpnState,
                serverName = profiles.firstOrNull { it.id == selectedId }?.name,
                onConnect = onConnect,
                onDisconnect = onDisconnect,
            )

            Spacer(Modifier.height(14.dp))
            Row(
                modifier = Modifier.align(Alignment.CenterHorizontally),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                ThemeChip("VPN", selected = connMode != XrayVpnService.MODE_PROXY) {
                    if (connMode == XrayVpnService.MODE_PROXY) {
                        connMode = "VPN"
                        Storage.connectionMode = "VPN"
                        if (vpnState is VpnState.Connected) {
                            scope.launch { onDisconnect(); kotlinx.coroutines.delay(600); onConnect() }
                        }
                    }
                }
                ThemeChip("Прокси", selected = connMode == XrayVpnService.MODE_PROXY) {
                    if (connMode != XrayVpnService.MODE_PROXY) {
                        connMode = XrayVpnService.MODE_PROXY
                        Storage.connectionMode = XrayVpnService.MODE_PROXY
                        if (vpnState is VpnState.Connected) {
                            scope.launch { onDisconnect(); kotlinx.coroutines.delay(600); onConnect() }
                        }
                    }
                }
            }

            (vpnState as? VpnState.Connected)?.takeIf { it.proxyOnly }?.let {
                Spacer(Modifier.height(10.dp))
                Text(
                    "Локальный прокси: HTTP 127.0.0.1:${XrayVpnService.HTTP_PORT} · SOCKS ${XrayVpnService.SOCKS_PORT}",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                )
            }

            statusMessage?.let {
                Spacer(Modifier.height(12.dp))
                Text(
                    it,
                    color = TextSecondary,
                    fontSize = 13.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                )
            }

            Spacer(Modifier.height(24.dp))

            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Серверы", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                Spacer(Modifier.weight(1f))
                if (profiles.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .glass(cornerRadius = 12.dp)
                            .clickable(enabled = !pinging) {
                                pinging = true
                                scope.launch {
                                    val targets = Storage.profiles
                                    val results = targets.map { p ->
                                        async { p.id to PingManager.measure(context, p) }
                                    }.awaitAll()
                                    pings = results.toMap()
                                    pinging = false
                                }
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            if (pinging) "Замер…" else "Пинг",
                            color = if (pinging) TextSecondary else NeonCyan,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))

            if (profiles.isEmpty()) {
                EmptyHint(onAdd = { showAddDialog = true })
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(profiles, key = { it.id }) { profile ->
                        ServerCard(
                            profile = profile,
                            selected = profile.id == selectedId,
                            pingMs = pings[profile.id],
                            onSelect = {
                                Storage.selectedProfileId = profile.id
                                selectedId = profile.id
                            },
                            onDelete = {
                                Storage.removeProfile(profile.id)
                                profiles = Storage.profiles
                                selectedId = Storage.selectedProfileId
                            },
                        )
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }
        }

        if (showSettings) {
            SettingsScreen(
                themeMode = themeMode,
                onThemeChange = onThemeChange,
                onClose = { showSettings = false },
            )
        }

        if (showAddDialog) {
            AddDialog(
                onDismiss = { showAddDialog = false },
                onResult = { message ->
                    statusMessage = message
                    profiles = Storage.profiles
                    selectedId = Storage.selectedProfileId
                    showAddDialog = false
                },
            )
        }
    }
}

@Composable
private fun TopBar(onAdd: () -> Unit, onRefresh: () -> Unit, onSettings: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "Vanna_vpn",
            color = TextPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.weight(1f))
        GlassIconButton("⟳", onRefresh)
        Spacer(Modifier.width(10.dp))
        GlassIconButton("+", onAdd)
        Spacer(Modifier.width(10.dp))
        Box(
            modifier = Modifier
                .size(42.dp)
                .glass(cornerRadius = 14.dp)
                .clickable(onClick = onSettings),
            contentAlignment = Alignment.Center,
        ) {
            GearIcon(color = TextPrimary, size = 20.dp)
        }
    }
}

/** Gear drawn with Canvas — keeps the icon independent of device fonts. */
@Composable
private fun GearIcon(color: Color, size: androidx.compose.ui.unit.Dp) {
    androidx.compose.foundation.Canvas(modifier = Modifier.size(size)) {
        val px = this.size.minDimension
        val c = androidx.compose.ui.geometry.Offset(px / 2, px / 2)
        val stroke = px * 0.12f
        // teeth
        for (i in 0 until 8) {
            val angle = Math.toRadians(i * 45.0)
            val cos = kotlin.math.cos(angle).toFloat()
            val sin = kotlin.math.sin(angle).toFloat()
            drawLine(
                color = color,
                start = androidx.compose.ui.geometry.Offset(c.x + cos * px * 0.30f, c.y + sin * px * 0.30f),
                end = androidx.compose.ui.geometry.Offset(c.x + cos * px * 0.46f, c.y + sin * px * 0.46f),
                strokeWidth = stroke,
                cap = androidx.compose.ui.graphics.StrokeCap.Round,
            )
        }
        // body ring
        drawCircle(
            color = color,
            radius = px * 0.28f,
            center = c,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke),
        )
        // hub
        drawCircle(color = color, radius = px * 0.08f, center = c)
    }
}

private const val TELEGRAM_URL = "https://t.me/Vanaa_Vpn_bot"

@Composable
private fun SettingsScreen(
    themeMode: ThemeMode,
    onThemeChange: (ThemeMode) -> Unit,
    onClose: () -> Unit,
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var routingMode by remember { mutableStateOf(Storage.routingMode) }
    var directRules by remember { mutableStateOf(Storage.directRules) }
    var blockRules by remember { mutableStateOf(Storage.blockRules) }
    val appVersion = remember {
        runCatching {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName
        }.getOrNull() ?: ""
    }
    val coreVersion = remember {
        runCatching { libv2ray.Libv2ray.checkVersionX() }.getOrDefault("Xray-core")
    }

    androidx.activity.compose.BackHandler(onBack = onClose)

    LiquidBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
        ) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .glass(cornerRadius = 14.dp)
                        .clickable(onClick = onClose),
                    contentAlignment = Alignment.Center,
                ) {
                    BackChevron(color = TextPrimary, size = 16.dp)
                }
                Spacer(Modifier.width(14.dp))
                Text("Настройки", color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }

            SectionLabel("ВНЕШНИЙ ВИД")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ThemeChip("Тёмная", selected = themeMode == ThemeMode.DARK) { onThemeChange(ThemeMode.DARK) }
                ThemeChip("Светлая", selected = themeMode == ThemeMode.LIGHT) { onThemeChange(ThemeMode.LIGHT) }
            }

            SectionLabel("МАРШРУТИЗАЦИЯ")
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                RoutingOptionCard(
                    title = "Проксировать всё",
                    subtitle = "Весь трафик идёт через VPN",
                    selected = routingMode == RoutingOptions.MODE_GLOBAL,
                ) { routingMode = RoutingOptions.MODE_GLOBAL; Storage.routingMode = routingMode }
                RoutingOptionCard(
                    title = "Обход локальных адресов",
                    subtitle = "Домашняя сеть (роутер, принтер) — напрямую",
                    selected = routingMode == RoutingOptions.MODE_BYPASS_LAN,
                ) { routingMode = RoutingOptions.MODE_BYPASS_LAN; Storage.routingMode = routingMode }
                RoutingOptionCard(
                    title = "Обход РФ",
                    subtitle = "Российские сайты и IP — напрямую, остальное через VPN",
                    selected = routingMode == RoutingOptions.MODE_BYPASS_RU,
                ) { routingMode = RoutingOptions.MODE_BYPASS_RU; Storage.routingMode = routingMode }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Применяется при следующем подключении",
                color = TextSecondary,
                fontSize = 12.sp,
            )

            SectionLabel("СВОИ ПРАВИЛА")
            RulesField(
                label = "Напрямую (мимо VPN)",
                value = directRules,
                onValueChange = { directRules = it; Storage.directRules = it },
            )
            Spacer(Modifier.height(12.dp))
            RulesField(
                label = "Заблокировать",
                value = blockRules,
                onValueChange = { blockRules = it; Storage.blockRules = it },
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "По одному в строке: домен (example.com), IP/подсеть (1.2.3.4 или 10.0.0.0/8), geosite:category-ads-all",
                color = TextSecondary,
                fontSize = 12.sp,
            )

            SectionLabel("СВЯЗЬ")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .glass(cornerRadius = 18.dp)
                    .clickable {
                        runCatching {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, android.net.Uri.parse(TELEGRAM_URL))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        }
                    }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PaperPlaneIcon(color = NeonCyan, size = 22.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Telegram-бот", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text("@Vanaa_Vpn_bot — поддержка и новости", color = TextSecondary, fontSize = 12.sp)
                }
                Text("›", color = TextSecondary, fontSize = 20.sp)
            }

            SectionLabel("О ПРИЛОЖЕНИИ")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .glass(cornerRadius = 18.dp)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
            ) {
                Text("Vanna_vpn $appVersion", color = TextPrimary, fontSize = 14.sp)
                Spacer(Modifier.height(2.dp))
                Text(coreVersion, color = TextSecondary, fontSize = 12.sp)
            }

            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Spacer(Modifier.height(24.dp))
    Text(text, color = TextSecondary, fontSize = 12.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun RoutingOptionCard(title: String, subtitle: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .glass(cornerRadius = 18.dp, fill = if (selected) CardSelectedFill else GlassWhite)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(2.dp))
            Text(subtitle, color = TextSecondary, fontSize = 12.sp)
        }
        if (selected) {
            Spacer(Modifier.width(8.dp))
            Text("✓", color = NeonMint, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun RulesField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label, color = TextSecondary, fontSize = 13.sp) },
        placeholder = { Text("example.com\n1.2.3.4", color = TextSecondary) },
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            focusedBorderColor = NeonCyan,
            unfocusedBorderColor = FieldBorder,
            cursorColor = NeonCyan,
        ),
        shape = RoundedCornerShape(14.dp),
        minLines = 2,
        maxLines = 6,
    )
}

/** Back chevron drawn with Canvas — independent of device fonts. */
@Composable
private fun BackChevron(color: Color, size: androidx.compose.ui.unit.Dp) {
    androidx.compose.foundation.Canvas(modifier = Modifier.size(size)) {
        val px = this.size.minDimension
        val stroke = px * 0.14f
        drawLine(
            color = color,
            start = androidx.compose.ui.geometry.Offset(px * 0.65f, px * 0.1f),
            end = androidx.compose.ui.geometry.Offset(px * 0.3f, px * 0.5f),
            strokeWidth = stroke,
            cap = androidx.compose.ui.graphics.StrokeCap.Round,
        )
        drawLine(
            color = color,
            start = androidx.compose.ui.geometry.Offset(px * 0.3f, px * 0.5f),
            end = androidx.compose.ui.geometry.Offset(px * 0.65f, px * 0.9f),
            strokeWidth = stroke,
            cap = androidx.compose.ui.graphics.StrokeCap.Round,
        )
    }
}

/** Minimal Telegram-style paper plane drawn with Canvas. */
@Composable
private fun PaperPlaneIcon(color: Color, size: androidx.compose.ui.unit.Dp) {
    androidx.compose.foundation.Canvas(modifier = Modifier.size(size)) {
        val px = this.size.minDimension
        val path = androidx.compose.ui.graphics.Path().apply {
            moveTo(px * 0.95f, px * 0.08f)
            lineTo(px * 0.05f, px * 0.5f)
            lineTo(px * 0.35f, px * 0.62f)
            lineTo(px * 0.42f, px * 0.9f)
            lineTo(px * 0.58f, px * 0.7f)
            lineTo(px * 0.82f, px * 0.82f)
            close()
        }
        drawPath(path, color = color)
    }
}

@Composable
private fun ThemeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .glass(cornerRadius = 12.dp, fill = if (selected) CardSelectedFill else GlassWhite)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = if (selected) TextPrimary else TextSecondary,
            fontSize = 14.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        )
    }
}

@Composable
private fun GlassIconButton(symbol: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(42.dp)
            .glass(cornerRadius = 14.dp)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(symbol, color = TextPrimary, fontSize = 20.sp)
    }
}

@Composable
private fun ConnectOrb(
    state: VpnState,
    serverName: String?,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
) {
    val (ringBrush, label) = when (state) {
        is VpnState.Connected -> Brush.sweepGradient(listOf(NeonMint, NeonCyan, NeonMint)) to "ПОДКЛЮЧЕНО"
        is VpnState.Connecting -> Brush.sweepGradient(listOf(NeonViolet, NeonCyan, NeonViolet)) to "ПОДКЛЮЧЕНИЕ…"
        is VpnState.Error -> Brush.sweepGradient(listOf(DangerRed, NeonViolet, DangerRed)) to "ОШИБКА"
        else -> Brush.sweepGradient(listOf(NeonViolet, Color(0x807C5CFF), NeonViolet)) to "ОТКЛЮЧЕНО"
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .size(190.dp)
                .background(ringBrush, CircleShape)
                .padding(3.dp)
                .background(OrbInner, CircleShape)
                .padding(10.dp)
                .glass(cornerRadius = 100.dp)
                .clickable {
                    when (state) {
                        is VpnState.Connected, is VpnState.Connecting -> onDisconnect()
                        else -> onConnect()
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            if (state is VpnState.Connecting) {
                CircularProgressIndicator(color = NeonCyan, modifier = Modifier.size(48.dp))
            } else {
                PowerIcon(
                    color = if (state is VpnState.Connected) NeonMint else TextSecondary,
                    size = 56.dp,
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(label, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, letterSpacing = 2.sp)
        serverName?.let {
            Spacer(Modifier.height(4.dp))
            Text(it, color = TextSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** Power symbol drawn with Canvas — the ⏻ glyph is missing in many device fonts. */
@Composable
private fun PowerIcon(color: Color, size: androidx.compose.ui.unit.Dp) {
    androidx.compose.foundation.Canvas(modifier = Modifier.size(size)) {
        val px = this.size.minDimension
        val stroke = px * 0.1f
        drawArc(
            color = color,
            startAngle = -60f,
            sweepAngle = 300f,
            useCenter = false,
            topLeft = androidx.compose.ui.geometry.Offset(stroke / 2, stroke / 2),
            size = androidx.compose.ui.geometry.Size(px - stroke, px - stroke),
            style = androidx.compose.ui.graphics.drawscope.Stroke(
                width = stroke,
                cap = androidx.compose.ui.graphics.StrokeCap.Round,
            ),
        )
        drawLine(
            color = color,
            start = androidx.compose.ui.geometry.Offset(px / 2, 0f),
            end = androidx.compose.ui.geometry.Offset(px / 2, px * 0.42f),
            strokeWidth = stroke,
            cap = androidx.compose.ui.graphics.StrokeCap.Round,
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ServerCard(
    profile: ServerProfile,
    selected: Boolean,
    pingMs: Long?,
    onSelect: () -> Unit,
    onDelete: () -> Unit,
) {
    var confirmDelete by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .glass(cornerRadius = 18.dp, fill = if (selected) CardSelectedFill else GlassWhite)
            .combinedClickable(onClick = onSelect, onLongClick = { confirmDelete = true })
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .glass(cornerRadius = 8.dp, fill = BadgeFill)
                .padding(horizontal = 8.dp, vertical = 4.dp),
        ) {
            Text(profile.displayProtocol, color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                profile.name,
                color = TextPrimary,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                "${profile.address}:${profile.port}",
                color = TextSecondary,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        pingMs?.let { ms ->
            Spacer(Modifier.width(8.dp))
            val (pingText, pingColor) = when {
                ms < 0 -> "✕" to DangerRed
                ms < 200 -> "$ms ms" to NeonMint
                ms < 500 -> "$ms ms" to Color(0xFFFFC857)
                else -> "$ms ms" to DangerRed
            }
            Text(pingText, color = pingColor, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        if (selected) {
            Spacer(Modifier.width(8.dp))
            Text("✓", color = NeonMint, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }

    if (confirmDelete) {
        Dialog(onDismissRequest = { confirmDelete = false }) {
            Column(
                modifier = Modifier
                    .glass(cornerRadius = 22.dp, fill = DialogFill)
                    .padding(22.dp),
            ) {
                Text("Удалить сервер?", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Spacer(Modifier.height(6.dp))
                Text(profile.name, color = TextSecondary, fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = { confirmDelete = false }) { Text("Отмена", color = TextSecondary) }
                    TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Удалить", color = DangerRed) }
                }
            }
        }
    }
}

@Composable
private fun EmptyHint(onAdd: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .glass()
            .clickable(onClick = onAdd)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Нет серверов", color = TextPrimary, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text(
            "Нажми, чтобы добавить подписку или ссылку (vless:// vmess:// trojan:// ss://)",
            color = TextSecondary,
            fontSize = 13.sp,
        )
    }
}

@Composable
private fun AddDialog(onDismiss: () -> Unit, onResult: (String) -> Unit) {
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Dialog(onDismissRequest = { if (!loading) onDismiss() }) {
        Column(
            modifier = Modifier
                .glass(cornerRadius = 22.dp, fill = DialogFill)
                .padding(22.dp),
        ) {
            Text("Добавить", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                "Ссылка-подписка (https://…) или ссылка сервера (vless:// vmess:// trojan:// ss://)",
                color = TextSecondary,
                fontSize = 12.sp,
            )
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("https://… или vless://…", color = TextSecondary) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = FieldBorder,
                    cursorColor = NeonCyan,
                ),
                shape = RoundedCornerShape(14.dp),
                maxLines = 4,
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    val value = input.trim()
                    if (value.isEmpty() || loading) return@Button
                    loading = true
                    scope.launch {
                        val message = runCatching {
                            if (value.startsWith("http://") || value.startsWith("https://")) {
                                val count = SubscriptionManager.add(value)
                                "Добавлено серверов: $count"
                            } else {
                                val profile = LinkParser.parseLink(value)
                                Storage.addProfiles(listOf(profile))
                                "Сервер «${profile.name}» добавлен"
                            }
                        }.getOrElse { "Ошибка: ${it.message}" }
                        loading = false
                        onResult(message)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = NeonViolet),
                shape = RoundedCornerShape(14.dp),
            ) {
                if (loading) {
                    CircularProgressIndicator(
                        color = TextPrimary,
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                    )
                } else {
                    Text("Добавить", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
