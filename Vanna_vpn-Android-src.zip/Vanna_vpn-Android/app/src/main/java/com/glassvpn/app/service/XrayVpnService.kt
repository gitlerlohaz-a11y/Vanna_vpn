package com.glassvpn.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.provider.Settings
import android.util.Base64
import android.util.Log
import com.glassvpn.app.R
import com.glassvpn.app.core.ServerProfile
import com.glassvpn.app.core.Storage
import com.glassvpn.app.core.XrayConfigBuilder
import com.glassvpn.app.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray

class XrayVpnService : VpnService() {

    companion object {
        const val ACTION_CONNECT = "com.glassvpn.app.CONNECT"
        const val ACTION_DISCONNECT = "com.glassvpn.app.DISCONNECT"
        const val MODE_PROXY = "PROXY"
        const val SOCKS_PORT = 10808
        const val HTTP_PORT = 10809
        private const val TAG = "GlassVPN"
        private const val NOTIFICATION_ID = 1
        private const val CHANNEL_ID = "vpn_state"

        @Volatile
        private var coreEnvInitialized = false

        fun initCoreEnv(context: Context) {
            if (coreEnvInitialized) return
            synchronized(this) {
                if (coreEnvInitialized) return
                copyGeoAssets(context)
                Libv2ray.initCoreEnv(context.filesDir.absolutePath, xudpBaseKey(context))
                coreEnvInitialized = true
            }
        }

        /** The core reads geo files from filesDir; copy them out of the APK assets on first run. */
        private fun copyGeoAssets(context: Context) {
            for (name in listOf("geoip.dat", "geosite.dat")) {
                val target = java.io.File(context.filesDir, name)
                if (target.exists() && target.length() > 0) continue
                runCatching {
                    context.assets.open(name).use { input ->
                        target.outputStream().use { output -> input.copyTo(output) }
                    }
                    Log.i(TAG, "Copied $name to ${target.absolutePath}")
                }.onFailure { Log.e(TAG, "Failed to copy $name", it) }
            }
        }

        private fun xudpBaseKey(context: Context): String {
            val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
                ?: "glassvpn-default-key"
            val bytes = androidId.toByteArray(Charsets.UTF_8).copyOf(32)
            return Base64.encodeToString(bytes, Base64.NO_PADDING or Base64.URL_SAFE or Base64.NO_WRAP)
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var tunInterface: ParcelFileDescriptor? = null
    private var proxyPipe: Array<ParcelFileDescriptor>? = null
    private var coreController: CoreController? = null
    private var currentProfile: ServerProfile? = null

    private val connectivity by lazy { getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager }

    private val defaultNetworkRequest by lazy {
        NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_RESTRICTED)
            .build()
    }

    private val defaultNetworkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            setUnderlyingNetworks(arrayOf(network))
        }
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            setUnderlyingNetworks(arrayOf(network))
        }
        override fun onLost(network: Network) {
            setUnderlyingNetworks(null)
        }
    }

    private val coreCallback = object : CoreCallbackHandler {
        override fun startup(): Long = 0
        override fun shutdown(): Long {
            scope.launch { stopVpn() }
            return 0
        }
        override fun onEmitStatus(code: Long, message: String?): Long = 0
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISCONNECT -> {
                stopVpn()
                return START_NOT_STICKY
            }
            else -> {
                val profile = Storage.selectedProfile()
                if (profile == null) {
                    VpnStateBus.update(VpnState.Error("Сервер не выбран"))
                    stopSelf()
                    return START_NOT_STICKY
                }
                startVpn(profile)
            }
        }
        return START_STICKY
    }

    private fun startVpn(profile: ServerProfile) {
        VpnStateBus.update(VpnState.Connecting)
        startForeground(NOTIFICATION_ID, buildNotification(profile.name))

        scope.launch {
            try {
                initCoreEnv(this@XrayVpnService)
                stopCoreQuietly()

                val proxyOnly = Storage.connectionMode == MODE_PROXY
                val controller = Libv2ray.newCoreController(coreCallback)

                if (proxyOnly) {
                    // local socks/http inbounds only — no TUN, no VPN consent needed
                    val config = XrayConfigBuilder.build(
                        profile,
                        forTun = false,
                        routing = Storage.routingOptions(),
                        socksPort = SOCKS_PORT,
                        httpPort = HTTP_PORT,
                    )
                    // the core API needs an fd; a dummy pipe keeps it harmlessly idle
                    val pipe = ParcelFileDescriptor.createPipe()
                    proxyPipe = pipe
                    controller.startLoop(config, pipe[0].fd)
                } else {
                    val tun = establishTun() ?: error("Не удалось создать TUN-интерфейс")
                    tunInterface = tun

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        runCatching { connectivity.requestNetwork(defaultNetworkRequest, defaultNetworkCallback) }
                    }

                    val config = XrayConfigBuilder.build(profile, forTun = true, routing = Storage.routingOptions())
                    controller.startLoop(config, tun.fd)
                }
                if (!controller.isRunning) error("Ядро Xray не запустилось")

                coreController = controller
                currentProfile = profile
                VpnStateBus.update(VpnState.Connected(profile.name, proxyOnly))
                Log.i(TAG, "Connected to ${profile.name} proxyOnly=$proxyOnly (${Libv2ray.checkVersionX()})")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start VPN", e)
                VpnStateBus.update(VpnState.Error(e.message ?: "Ошибка запуска"))
                stopVpn()
            }
        }
    }

    private fun establishTun(): ParcelFileDescriptor? {
        val builder = Builder()
            .setSession(getString(R.string.app_name))
            .setMtu(XrayConfigBuilder.MTU)
            .addAddress("26.26.26.1", 30)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")

        // The Xray core dials real connections from this app's UID;
        // excluding our own package keeps core traffic off the TUN (no protect() needed).
        runCatching { builder.addDisallowedApplication(packageName) }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            builder.setMetered(false)
        }
        return builder.establish()
    }

    private fun stopCoreQuietly() {
        runCatching { coreController?.stopLoop() }
        coreController = null
    }

    private fun stopVpn() {
        stopCoreQuietly()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            runCatching { connectivity.unregisterNetworkCallback(defaultNetworkCallback) }
        }
        runCatching { tunInterface?.close() }
        tunInterface = null
        proxyPipe?.forEach { runCatching { it.close() } }
        proxyPipe = null
        currentProfile = null
        VpnStateBus.update(VpnState.Disconnected)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        }
        stopSelf()
    }

    override fun onRevoke() {
        stopVpn()
    }

    override fun onDestroy() {
        stopCoreQuietly()
        runCatching { tunInterface?.close() }
        proxyPipe?.forEach { runCatching { it.close() } }
        scope.cancel()
        super.onDestroy()
    }

    private fun buildNotification(serverName: String): Notification {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.notification_channel), NotificationManager.IMPORTANCE_LOW)
            )
        }

        val contentIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, XrayVpnService::class.java).setAction(ACTION_DISCONNECT),
            PendingIntent.FLAG_IMMUTABLE
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notification_connected, serverName))
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, getString(R.string.disconnect), stopIntent).build())
            .build()
    }
}
