package com.glassvpn.app

import android.app.Application
import com.glassvpn.app.core.Storage

class GlassApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Storage.init(this)
    }
}
