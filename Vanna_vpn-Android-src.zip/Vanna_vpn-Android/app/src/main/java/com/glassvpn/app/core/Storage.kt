package com.glassvpn.app.core

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

data class Subscription(
    val url: String,
    val name: String = "",
    val lastUpdated: Long = 0L,
)

/** SharedPreferences-backed store for profiles, subscriptions and selection. */
object Storage {

    private const val PREFS = "glassvpn"
    private const val KEY_PROFILES = "profiles"
    private const val KEY_SUBSCRIPTIONS = "subscriptions"
    private const val KEY_SELECTED = "selected_profile_id"
    private const val KEY_THEME = "theme_mode"
    private const val KEY_ROUTING_MODE = "routing_mode"
    private const val KEY_CONN_MODE = "connection_mode"
    private const val KEY_DIRECT_RULES = "direct_rules"
    private const val KEY_BLOCK_RULES = "block_rules"

    private lateinit var prefs: SharedPreferences
    private val gson = Gson()

    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    var profiles: List<ServerProfile>
        get() = readList(KEY_PROFILES, object : TypeToken<List<ServerProfile>>() {})
        set(value) = prefs.edit().putString(KEY_PROFILES, gson.toJson(value)).apply()

    var subscriptions: List<Subscription>
        get() = readList(KEY_SUBSCRIPTIONS, object : TypeToken<List<Subscription>>() {})
        set(value) = prefs.edit().putString(KEY_SUBSCRIPTIONS, gson.toJson(value)).apply()

    var selectedProfileId: String?
        get() = prefs.getString(KEY_SELECTED, null)
        set(value) = prefs.edit().putString(KEY_SELECTED, value).apply()

    /** "DARK" (default) or "LIGHT" — kept as a string to stay decoupled from UI enums. */
    var themeMode: String
        get() = prefs.getString(KEY_THEME, "DARK") ?: "DARK"
        set(value) = prefs.edit().putString(KEY_THEME, value).apply()

    /** GLOBAL / BYPASS_LAN / BYPASS_RU (see [RoutingOptions]). */
    /** "VPN" (TUN via VpnService, default) or "PROXY" (local socks/http only, no TUN). */
    var connectionMode: String
        get() = prefs.getString(KEY_CONN_MODE, "VPN") ?: "VPN"
        set(value) = prefs.edit().putString(KEY_CONN_MODE, value).apply()

    var routingMode: String
        get() = prefs.getString(KEY_ROUTING_MODE, RoutingOptions.MODE_BYPASS_LAN)
            ?: RoutingOptions.MODE_BYPASS_LAN
        set(value) = prefs.edit().putString(KEY_ROUTING_MODE, value).apply()

    /** Newline-separated user rules (domains / IPs / geoip: / geosite:). */
    var directRules: String
        get() = prefs.getString(KEY_DIRECT_RULES, "") ?: ""
        set(value) = prefs.edit().putString(KEY_DIRECT_RULES, value).apply()

    var blockRules: String
        get() = prefs.getString(KEY_BLOCK_RULES, "") ?: ""
        set(value) = prefs.edit().putString(KEY_BLOCK_RULES, value).apply()

    fun routingOptions(): RoutingOptions = RoutingOptions(
        mode = routingMode,
        directRules = directRules.lines().map { it.trim() }.filter { it.isNotEmpty() },
        blockRules = blockRules.lines().map { it.trim() }.filter { it.isNotEmpty() },
    )

    fun selectedProfile(): ServerProfile? {
        val id = selectedProfileId ?: return null
        return profiles.firstOrNull { it.id == id }
    }

    fun addProfiles(newProfiles: List<ServerProfile>) {
        profiles = profiles + newProfiles
        if (selectedProfileId == null && newProfiles.isNotEmpty()) {
            selectedProfileId = newProfiles.first().id
        }
    }

    fun removeProfile(id: String) {
        profiles = profiles.filterNot { it.id == id }
        if (selectedProfileId == id) selectedProfileId = profiles.firstOrNull()?.id
    }

    /** Replaces all profiles that came from [subscriptionUrl] with [fresh] ones. */
    fun replaceSubscriptionProfiles(subscriptionUrl: String, fresh: List<ServerProfile>) {
        val keptSelectionName = selectedProfile()?.takeIf { it.subscriptionUrl == subscriptionUrl }?.name
        profiles = profiles.filterNot { it.subscriptionUrl == subscriptionUrl } + fresh
        if (profiles.none { it.id == selectedProfileId }) {
            selectedProfileId = fresh.firstOrNull { it.name == keptSelectionName }?.id
                ?: profiles.firstOrNull()?.id
        }
    }

    private inline fun <reified T> readList(key: String, token: TypeToken<List<T>>): List<T> {
        val raw = prefs.getString(key, null) ?: return emptyList()
        return runCatching { gson.fromJson<List<T>>(raw, token.type) }.getOrNull() ?: emptyList()
    }
}
