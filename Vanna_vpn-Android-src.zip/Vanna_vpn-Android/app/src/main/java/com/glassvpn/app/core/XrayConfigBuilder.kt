package com.glassvpn.app.core

import com.google.gson.GsonBuilder
import com.google.gson.JsonArray
import com.google.gson.JsonObject

/**
 * Builds a full Xray-core JSON config from a [ServerProfile].
 * Pure JVM code — covered by unit tests.
 */
/** Routing behavior for the tunnel. Pure JVM — covered by unit tests. */
data class RoutingOptions(
    val mode: String = MODE_BYPASS_LAN,
    /** Newline-entered user rules: domains, IPs/CIDR, geoip:/geosite: tags. */
    val directRules: List<String> = emptyList(),
    val blockRules: List<String> = emptyList(),
) {
    companion object {
        const val MODE_GLOBAL = "GLOBAL"        // proxy everything
        const val MODE_BYPASS_LAN = "BYPASS_LAN" // private IPs go direct (default)
        const val MODE_BYPASS_RU = "BYPASS_RU"   // private + Russian IPs/domains go direct
    }
}

object XrayConfigBuilder {

    private val gson = GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create()

    const val MTU = 1500

    /**
     * @param forTun when true, adds the "tun" inbound that picks up the VpnService fd
     *               (AndroidLibXrayLite reads it from the xray.tun.fd env variable).
     *               When false (ping/speed test), the config has no inbounds and no routing rules.
     */
    fun build(
        profile: ServerProfile,
        forTun: Boolean = true,
        routing: RoutingOptions = RoutingOptions(),
        socksPort: Int = 0,
        httpPort: Int = 0,
    ): String {
        val root = JsonObject()

        root.add("log", JsonObject().apply { addProperty("loglevel", "warning") })

        root.add("dns", JsonObject().apply {
            add("servers", JsonArray().apply {
                add("1.1.1.1")
                add("8.8.8.8")
            })
        })

        val inbounds = JsonArray()
        if (forTun) {
            inbounds.add(JsonObject().apply {
                addProperty("tag", "tun")
                addProperty("protocol", "tun")
                add("settings", JsonObject().apply {
                    addProperty("name", "xray0")
                    addProperty("MTU", MTU)
                    addProperty("userLevel", 8)
                })
                add("sniffing", JsonObject().apply {
                    addProperty("enabled", true)
                    add("destOverride", JsonArray().apply { add("http"); add("tls"); add("quic") })
                })
            })
        }
        if (socksPort > 0) {
            inbounds.add(JsonObject().apply {
                addProperty("tag", "socks-in")
                addProperty("protocol", "socks")
                addProperty("listen", "127.0.0.1")
                addProperty("port", socksPort)
                add("settings", JsonObject().apply { addProperty("udp", true) })
                add("sniffing", JsonObject().apply {
                    addProperty("enabled", true)
                    add("destOverride", JsonArray().apply { add("http"); add("tls"); add("quic") })
                })
            })
        }
        if (httpPort > 0) {
            inbounds.add(JsonObject().apply {
                addProperty("tag", "http-in")
                addProperty("protocol", "http")
                addProperty("listen", "127.0.0.1")
                addProperty("port", httpPort)
                add("sniffing", JsonObject().apply {
                    addProperty("enabled", true)
                    add("destOverride", JsonArray().apply { add("http"); add("tls") })
                })
            })
        }
        root.add("inbounds", inbounds)

        val outbounds = JsonArray()
        outbounds.add(buildProxyOutbound(profile))
        outbounds.add(JsonObject().apply {
            addProperty("tag", "direct")
            addProperty("protocol", "freedom")
        })
        outbounds.add(JsonObject().apply {
            addProperty("tag", "block")
            addProperty("protocol", "blackhole")
        })
        root.add("outbounds", outbounds)

        root.add("routing", JsonObject().apply {
            addProperty("domainStrategy", "IPIfNonMatch")
            // geoip/geosite rules need .dat files in filesDir; ping configs stay independent of geo files
            add("rules", if (forTun || socksPort > 0) buildRoutingRules(routing) else JsonArray())
        })

        return gson.toJson(root)
    }

    private fun buildRoutingRules(routing: RoutingOptions): JsonArray {
        val rules = JsonArray()
        // user rules first — they win over mode defaults
        rule(routing.blockRules, "block")?.let { rules.add(it) }
        rule(routing.directRules, "direct")?.let { rules.add(it) }

        when (routing.mode) {
            RoutingOptions.MODE_BYPASS_LAN -> {
                rules.add(ipRule(listOf("geoip:private"), "direct"))
            }
            RoutingOptions.MODE_BYPASS_RU -> {
                rules.add(ipRule(listOf("geoip:private", "geoip:ru"), "direct"))
                rules.add(domainRule(listOf("domain:ru", "domain:su", "domain:xn--p1ai"), "direct"))
            }
            // MODE_GLOBAL: no extra rules — everything goes through the proxy
        }
        return rules
    }

    /** Splits mixed user entries into ip/domain criteria; returns null when the list is empty. */
    private fun rule(entries: List<String>, outboundTag: String): JsonObject? {
        val ips = JsonArray()
        val domains = JsonArray()
        entries.map { it.trim() }.filter { it.isNotEmpty() }.forEach { entry ->
            when {
                entry.startsWith("geoip:") -> ips.add(entry)
                entry.startsWith("geosite:") || entry.startsWith("domain:") ||
                    entry.startsWith("full:") || entry.startsWith("regexp:") -> domains.add(entry)
                isIpOrCidr(entry) -> ips.add(entry)
                else -> domains.add("domain:$entry")
            }
        }
        if (ips.isEmpty() && domains.isEmpty()) return null
        return JsonObject().apply {
            addProperty("type", "field")
            if (ips.size() > 0) add("ip", ips)
            if (domains.size() > 0) add("domain", domains)
            addProperty("outboundTag", outboundTag)
        }
    }

    private fun ipRule(ips: List<String>, outboundTag: String) = JsonObject().apply {
        addProperty("type", "field")
        add("ip", JsonArray().apply { ips.forEach { add(it) } })
        addProperty("outboundTag", outboundTag)
    }

    private fun domainRule(domains: List<String>, outboundTag: String) = JsonObject().apply {
        addProperty("type", "field")
        add("domain", JsonArray().apply { domains.forEach { add(it) } })
        addProperty("outboundTag", outboundTag)
    }

    private val ipRegex = Regex("""^(\d{1,3}(\.\d{1,3}){3}|[0-9a-fA-F:]+:[0-9a-fA-F:]*)(/\d{1,3})?$""")

    fun isIpOrCidr(entry: String): Boolean = ipRegex.matches(entry)

    fun buildProxyOutbound(p: ServerProfile): JsonObject {
        val outbound = JsonObject()
        outbound.addProperty("tag", "proxy")
        outbound.addProperty("protocol", p.protocol)

        val settings = JsonObject()
        when (p.protocol) {
            "vless" -> {
                settings.add("vnext", JsonArray().apply {
                    add(JsonObject().apply {
                        addProperty("address", p.address)
                        addProperty("port", p.port)
                        add("users", JsonArray().apply {
                            add(JsonObject().apply {
                                addProperty("id", p.userId)
                                addProperty("encryption", "none")
                                if (p.flow.isNotBlank()) addProperty("flow", p.flow)
                                addProperty("level", 8)
                            })
                        })
                    })
                })
            }
            "vmess" -> {
                settings.add("vnext", JsonArray().apply {
                    add(JsonObject().apply {
                        addProperty("address", p.address)
                        addProperty("port", p.port)
                        add("users", JsonArray().apply {
                            add(JsonObject().apply {
                                addProperty("id", p.userId)
                                addProperty("alterId", p.alterId)
                                addProperty("security", p.cipher.ifBlank { "auto" })
                                addProperty("level", 8)
                            })
                        })
                    })
                })
            }
            "trojan" -> {
                settings.add("servers", JsonArray().apply {
                    add(JsonObject().apply {
                        addProperty("address", p.address)
                        addProperty("port", p.port)
                        addProperty("password", p.userId)
                        addProperty("level", 8)
                    })
                })
            }
            "shadowsocks" -> {
                settings.add("servers", JsonArray().apply {
                    add(JsonObject().apply {
                        addProperty("address", p.address)
                        addProperty("port", p.port)
                        addProperty("method", p.cipher)
                        addProperty("password", p.userId)
                        addProperty("level", 8)
                    })
                })
            }
            else -> throw IllegalArgumentException("Unsupported protocol: ${p.protocol}")
        }
        outbound.add("settings", settings)
        outbound.add("streamSettings", buildStreamSettings(p))
        outbound.add("mux", JsonObject().apply { addProperty("enabled", false) })
        return outbound
    }

    private fun buildStreamSettings(p: ServerProfile): JsonObject {
        val stream = JsonObject()
        stream.addProperty("network", p.network)

        when (p.network) {
            "ws" -> stream.add("wsSettings", JsonObject().apply {
                addProperty("path", p.path.ifBlank { "/" })
                if (p.host.isNotBlank()) addProperty("host", p.host)
            })
            "grpc" -> stream.add("grpcSettings", JsonObject().apply {
                addProperty("serviceName", p.serviceName.ifBlank { p.path.removePrefix("/") })
                addProperty("multiMode", p.mode == "multi")
            })
            "httpupgrade" -> stream.add("httpupgradeSettings", JsonObject().apply {
                addProperty("path", p.path.ifBlank { "/" })
                if (p.host.isNotBlank()) addProperty("host", p.host)
            })
            "xhttp" -> stream.add("xhttpSettings", JsonObject().apply {
                addProperty("path", p.path.ifBlank { "/" })
                if (p.host.isNotBlank()) addProperty("host", p.host)
                if (p.mode.isNotBlank()) addProperty("mode", p.mode)
            })
            "tcp" -> if (p.headerType == "http") {
                stream.add("tcpSettings", JsonObject().apply {
                    add("header", JsonObject().apply {
                        addProperty("type", "http")
                        add("request", JsonObject().apply {
                            add("headers", JsonObject().apply {
                                add("Host", JsonArray().apply {
                                    (p.host.ifBlank { p.address }).split(",").forEach { add(it.trim()) }
                                })
                            })
                            if (p.path.isNotBlank()) {
                                add("path", JsonArray().apply { add(p.path) })
                            }
                        })
                    })
                })
            }
        }

        when (p.security) {
            "tls" -> {
                stream.addProperty("security", "tls")
                stream.add("tlsSettings", JsonObject().apply {
                    addProperty("serverName", p.sni.ifBlank { p.host.ifBlank { p.address } })
                    addProperty("allowInsecure", p.allowInsecure)
                    if (p.fingerprint.isNotBlank()) addProperty("fingerprint", p.fingerprint)
                    if (p.alpn.isNotBlank()) {
                        add("alpn", JsonArray().apply {
                            p.alpn.split(",").map { it.trim() }.filter { it.isNotBlank() }.forEach { add(it) }
                        })
                    }
                })
            }
            "reality" -> {
                stream.addProperty("security", "reality")
                stream.add("realitySettings", JsonObject().apply {
                    addProperty("serverName", p.sni)
                    addProperty("publicKey", p.publicKey)
                    addProperty("shortId", p.shortId)
                    addProperty("spiderX", p.spiderX)
                    addProperty("fingerprint", p.fingerprint.ifBlank { "chrome" })
                    addProperty("show", false)
                })
            }
            else -> stream.addProperty("security", "none")
        }

        return stream
    }
}
