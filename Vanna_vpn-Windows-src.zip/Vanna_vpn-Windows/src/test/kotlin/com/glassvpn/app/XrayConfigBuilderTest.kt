package com.glassvpn.app

import com.glassvpn.app.core.RoutingOptions
import com.glassvpn.app.core.ServerProfile
import com.glassvpn.app.core.XrayConfigBuilder
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class XrayConfigBuilderTest {

    private fun parse(config: String): JsonObject = JsonParser.parseString(config).asJsonObject

    private val vlessReality = ServerProfile(
        name = "R", protocol = "vless", address = "1.2.3.4", port = 443,
        userId = "uuid-1", flow = "xtls-rprx-vision", network = "tcp",
        security = "reality", sni = "www.microsoft.com", fingerprint = "chrome",
        publicKey = "pbk123", shortId = "sid1", spiderX = "/",
    )

    @Test
    fun `proxy config has socks and http inbounds with routing`() {
        val root = parse(XrayConfigBuilder.build(vlessReality, socksPort = 10808, httpPort = 10809))
        val inbounds = root.getAsJsonArray("inbounds")
        assertEquals(2, inbounds.size())
        val socks = inbounds[0].asJsonObject
        assertEquals("socks", socks.get("protocol").asString)
        assertEquals(10808, socks.get("port").asInt)
        assertEquals("127.0.0.1", socks.get("listen").asString)
        assertTrue(socks.getAsJsonObject("sniffing").get("enabled").asBoolean)
        val http = inbounds[1].asJsonObject
        assertEquals("http", http.get("protocol").asString)
        assertEquals(10809, http.get("port").asInt)

        val rules = root.getAsJsonObject("routing").getAsJsonArray("rules")
        assertTrue(rules.size() >= 1)
        assertEquals("direct", rules[0].asJsonObject.get("outboundTag").asString)
    }

    @Test
    fun `socks only config skips http inbound`() {
        val root = parse(XrayConfigBuilder.build(vlessReality, socksPort = 20001))
        val inbounds = root.getAsJsonArray("inbounds")
        assertEquals(1, inbounds.size())
        assertEquals("socks", inbounds[0].asJsonObject.get("protocol").asString)
    }

    @Test
    fun `no ports means no inbounds and no rules`() {
        val root = parse(XrayConfigBuilder.build(vlessReality))
        assertEquals(0, root.getAsJsonArray("inbounds").size())
        assertEquals(0, root.getAsJsonObject("routing").getAsJsonArray("rules").size())
    }

    @Test
    fun `global mode has no routing rules`() {
        val opts = RoutingOptions(mode = RoutingOptions.MODE_GLOBAL)
        val root = parse(XrayConfigBuilder.build(vlessReality, socksPort = 10808, routing = opts))
        assertEquals(0, root.getAsJsonObject("routing").getAsJsonArray("rules").size())
    }

    @Test
    fun `bypass ru mode routes russian ips and domains direct`() {
        val opts = RoutingOptions(mode = RoutingOptions.MODE_BYPASS_RU)
        val root = parse(XrayConfigBuilder.build(vlessReality, socksPort = 10808, routing = opts))
        val rules = root.getAsJsonObject("routing").getAsJsonArray("rules")
        assertEquals(2, rules.size())
        val ipRule = rules[0].asJsonObject
        assertEquals("direct", ipRule.get("outboundTag").asString)
        assertTrue(ipRule.getAsJsonArray("ip").toString().contains("geoip:ru"))
        val domainRule = rules[1].asJsonObject
        assertTrue(domainRule.getAsJsonArray("domain").toString().contains("domain:ru"))
    }

    @Test
    fun `custom rules split into ip and domain criteria`() {
        val opts = RoutingOptions(
            mode = RoutingOptions.MODE_BYPASS_LAN,
            directRules = listOf("example.com", "1.2.3.4", "10.0.0.0/8", "geosite:category-ads-all"),
            blockRules = listOf("ads.evil.com"),
        )
        val root = parse(XrayConfigBuilder.build(vlessReality, socksPort = 10808, routing = opts))
        val rules = root.getAsJsonObject("routing").getAsJsonArray("rules")
        assertEquals(3, rules.size()) // block, direct, bypass-lan

        val block = rules[0].asJsonObject
        assertEquals("block", block.get("outboundTag").asString)
        assertTrue(block.getAsJsonArray("domain").toString().contains("domain:ads.evil.com"))

        val direct = rules[1].asJsonObject
        assertEquals("direct", direct.get("outboundTag").asString)
        assertTrue(direct.getAsJsonArray("ip").toString().contains("1.2.3.4"))
        assertTrue(direct.getAsJsonArray("domain").toString().contains("domain:example.com"))

        assertTrue(rules[2].asJsonObject.getAsJsonArray("ip").toString().contains("geoip:private"))
    }

    @Test
    fun `ip detection distinguishes ips from domains`() {
        assertTrue(XrayConfigBuilder.isIpOrCidr("192.168.1.1"))
        assertTrue(XrayConfigBuilder.isIpOrCidr("10.0.0.0/8"))
        assertTrue(XrayConfigBuilder.isIpOrCidr("2001:db8::1"))
        assertEquals(false, XrayConfigBuilder.isIpOrCidr("example.com"))
        assertEquals(false, XrayConfigBuilder.isIpOrCidr("1.2.3.4.com"))
    }

    @Test
    fun `vless reality outbound is correct`() {
        val root = parse(XrayConfigBuilder.build(vlessReality, socksPort = 10808, httpPort = 10809))
        val proxy = root.getAsJsonArray("outbounds")[0].asJsonObject
        assertEquals("vless", proxy.get("protocol").asString)
        val stream = proxy.getAsJsonObject("streamSettings")
        assertEquals("reality", stream.get("security").asString)
        assertEquals("www.microsoft.com", stream.getAsJsonObject("realitySettings").get("serverName").asString)
    }
}
