package com.glassvpn.app.core

import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.reflect.TypeToken
import java.io.File

data class Subscription(
    val url: String,
    val name: String = "",
    val lastUpdated: Long = 0L,
)

/**
 * JSON-file-backed store (desktop counterpart of the Android SharedPreferences Storage).
 * Lives in %APPDATA%/Vanna_vpn/settings.json (or ~/.config/Vanna_vpn on non-Windows).
 */
object Storage {

    private const val KEY_PROFILES = "profiles"
    private const val KEY_SUBSCRIPTIONS = "subscriptions"
    private const val KEY_SELECTED = "selected_profile_id"
    private const val KEY_THEME = "theme_mode"
    private const val KEY_ROUTING_MODE = "routing_mode"
    private const val KEY_CONN_MODE = "connection_mode"
    private const val KEY_DIRECT_RULES = "direct_rules"
    private const val KEY_BLOCK_RULES = "block_rules"

    private val gson = Gson()

    internal var file: File = defaultFile()
        set(value) {
            field = value
            data = load()
        }

    private fun defaultFile(): File {
        val base = System.getenv("APPDATA")?.let { File(it) }
            ?: File(System.getProperty("user.home"), ".config")
        return File(base, "Vanna_vpn/settings.json")
    }

    private var data: JsonObject = load()

    @Synchronized
    private fun load(): JsonObject =
        runCatching { JsonParser.parseString(file.readText()).asJsonObject }.getOrElse { JsonObject() }

    @Synchronized
    private fun save() {
        runCatching {
            file.parentFile?.mkdirs()
            file.writeText(gson.toJson(data))
        }
    }

    @Synchronized
    private fun getString(key: String, def: String?): String? =
        if (data.has(key) && !data.get(key).isJsonNull) data.get(key).asString else def

    @Synchronized
    private fun putString(key: String, value: String?) {
        if (value == null) data.remove(key) else data.addProperty(key, value)
        save()
    }

    var profiles: List<ServerProfile>
        get() = readList(KEY_PROFILES, object : TypeToken<List<ServerProfile>>() {})
        set(value) = putString(KEY_PROFILES, gson.toJson(value))

    var subscriptions: List<Subscription>
        get() = readList(KEY_SUBSCRIPTIONS, object : TypeToken<List<Subscription>>() {})
        set(value) = putString(KEY_SUBSCRIPTIONS, gson.toJson(value))

    var selectedProfileId: String?
        get() = getString(KEY_SELECTED, null)
        set(value) = putString(KEY_SELECTED, value)

    /** "DARK" (default) or "LIGHT" — kept as a string to stay decoupled from UI enums. */
    var themeMode: String
        get() = getString(KEY_THEME, "DARK") ?: "DARK"
        set(value) = putString(KEY_THEME, value)

    /** "PROXY" (system proxy, default) or "TUN" (full traffic interception, needs admin). */
    var connectionMode: String
        get() = getString(KEY_CONN_MODE, "PROXY") ?: "PROXY"
        set(value) = putString(KEY_CONN_MODE, value)

    /** GLOBAL / BYPASS_LAN / BYPASS_RU (see [RoutingOptions]). */
    var routingMode: String
        get() = getString(KEY_ROUTING_MODE, RoutingOptions.MODE_BYPASS_LAN)
            ?: RoutingOptions.MODE_BYPASS_LAN
        set(value) = putString(KEY_ROUTING_MODE, value)

    /** Newline-separated user rules (domains / IPs / geoip: / geosite:). */
    var directRules: String
        get() = getString(KEY_DIRECT_RULES, "") ?: ""
        set(value) = putString(KEY_DIRECT_RULES, value)

    var blockRules: String
        get() = getString(KEY_BLOCK_RULES, "") ?: ""
        set(value) = putString(KEY_BLOCK_RULES, value)

    fun routingOptions(): RoutingOptions = RoutingOptions(
        mode = routingMode,
        directRules = directRules.lines().map { it.trim() }.filter { it.isNotEmpty() },
        blockRules = blockRules.lines().map { it.trim() }.filter { it.isNotEmpty() },
    )

    fun selectedProfile(): ServerProfile? {
        val id = selectedProfileId ?: return null
        return profiles.firstOrNull { it.id == id }
    }

    fun addProfiles(newProfiles: List<ServerProfile>) {
        profiles = profiles + newProfiles
        if (selectedProfileId == null && newProfiles.isNotEmpty()) {
            selectedProfileId = newProfiles.first().id
        }
    }

    fun removeProfile(id: String) {
        profiles = profiles.filterNot { it.id == id }
        if (selectedProfileId == id) selectedProfileId = profiles.firstOrNull()?.id
    }

    /** Replaces all profiles that came from [subscriptionUrl] with [fresh] ones. */
    fun replaceSubscriptionProfiles(subscriptionUrl: String, fresh: List<ServerProfile>) {
        val keptSelectionName = selectedProfile()?.takeIf { it.subscriptionUrl == subscriptionUrl }?.name
        profiles = profiles.filterNot { it.subscriptionUrl == subscriptionUrl } + fresh
        if (profiles.none { it.id == selectedProfileId }) {
            selectedProfileId = fresh.firstOrNull { it.name == keptSelectionName }?.id
                ?: profiles.firstOrNull()?.id
        }
    }

    private inline fun <reified T> readList(key: String, token: TypeToken<List<T>>): List<T> {
        val raw = getString(key, null) ?: return emptyList()
        return runCatching { gson.fromJson<List<T>>(raw, token.type) }.getOrNull() ?: emptyList()
    }
}
