package com.glassvpn.app.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.Socket
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.TimeUnit

sealed class VpnState {
    data object Disconnected : VpnState()
    data object Connecting : VpnState()
    data class Connected(val serverName: String, val exitIp: String? = null) : VpnState()
    data class Error(val message: String) : VpnState()
}

/**
 * Runs the bundled xray binary with local SOCKS/HTTP inbounds and toggles the
 * Windows system proxy (v2rayN-style "system proxy" mode, no admin rights needed).
 */
object XrayManager {

    const val SOCKS_PORT = 10808
    const val HTTP_PORT = 10809

    private val _state = MutableStateFlow<VpnState>(VpnState.Disconnected)
    val state: StateFlow<VpnState> = _state

    private var process: Process? = null
    private val recentLog = ConcurrentLinkedDeque<String>()

    private val isWindows = System.getProperty("os.name").lowercase().contains("win")

    /** Root folder of the portable app (set by the launcher via -Dapp.dir). */
    fun appDir(): File = File(System.getProperty("app.dir") ?: System.getProperty("user.dir"))

    fun xrayDir(): File = File(appDir(), "xray")

    fun xrayBinary(): File = File(xrayDir(), if (isWindows) "xray.exe" else "xray")

    val coreVersion: String by lazy {
        runCatching {
            val p = ProcessBuilder(xrayBinary().absolutePath, "version")
                .directory(xrayDir()).redirectErrorStream(true).start()
            val line = p.inputStream.bufferedReader().readLine() ?: "Xray-core"
            p.waitFor()
            line.substringBefore("(").trim()
        }.getOrDefault("Xray-core")
    }

    init {
        Runtime.getRuntime().addShutdownHook(Thread {
            runCatching { TunManager.stop() }
            runCatching { process?.destroy() }
            runCatching { SystemProxy.disable() }
        })
    }

    const val MODE_PROXY = "PROXY"
    const val MODE_TUN = "TUN"

    /** Mode used by the active connection (for the status line in the UI). */
    @Volatile
    var activeMode: String = MODE_PROXY
        private set

    @Synchronized
    fun connect(profile: ServerProfile, routing: RoutingOptions, mode: String = MODE_PROXY) {
        stopProcess()
        TunManager.stop()
        _state.value = VpnState.Connecting
        recentLog.clear()
        try {
            val bin = xrayBinary()
            if (!bin.exists()) {
                _state.value = VpnState.Error("Не найден ${bin.name} рядом с приложением")
                return
            }
            // TUN intercepts everything at OS level; xray "direct" traffic would loop back
            // into the adapter, so the core always proxies in TUN mode (block rules kept).
            val effectiveRouting = if (mode == MODE_TUN) {
                RoutingOptions(mode = RoutingOptions.MODE_GLOBAL, blockRules = routing.blockRules)
            } else routing
            val config = XrayConfigBuilder.build(
                profile,
                socksPort = SOCKS_PORT,
                httpPort = HTTP_PORT,
                routing = effectiveRouting,
            )
            val cfgFile = File(xrayDir(), "config.json")
            cfgFile.writeText(config)

            val proc = ProcessBuilder(bin.absolutePath, "run", "-c", cfgFile.absolutePath)
                .directory(xrayDir())
                .redirectErrorStream(true)
                .start()
            process = proc
            val logFile = logFile().apply { writeText("") }
            Thread {
                runCatching {
                    proc.inputStream.bufferedReader().forEachLine { line ->
                        recentLog.addLast(line)
                        while (recentLog.size > 40) recentLog.pollFirst()
                        runCatching { logFile.appendText(line + "\n") }
                    }
                }
            }.apply { isDaemon = true }.start()

            // give the core a moment to bind ports / fail fast
            if (!waitPortOpen(SOCKS_PORT, timeoutMs = 5000) || !proc.isAlive) {
                val tail = recentLog.lastOrNull { it.contains("error", true) || it.contains("failed", true) }
                    ?: recentLog.lastOrNull().orEmpty()
                _state.value = VpnState.Error(("Ядро не запустилось. " + tail).trim().take(220))
                stopProcess()
                return
            }

            // real connectivity check through the tunnel before declaring success
            if (!testTunnel()) {
                val tail = recentLog.lastOrNull { it.contains("error", true) || it.contains("failed", true) }
                    .orEmpty()
                _state.value = VpnState.Error(
                    ("Сервер не отвечает — туннель не работает. Проверь ссылку/сервер. " + tail)
                        .trim().take(260)
                )
                stopProcess()
                return
            }

            if (mode == MODE_TUN) {
                val tunError = TunManager.start(profile.address, SOCKS_PORT)
                if (tunError != null) {
                    _state.value = VpnState.Error(tunError)
                    TunManager.stop()
                    stopProcess()
                    return
                }
            } else {
                SystemProxy.enable("127.0.0.1:$HTTP_PORT")
            }
            activeMode = mode
            // In TUN mode probe the real system route (no SOCKS) so the shown IP
            // reflects what the browser actually sees; in proxy mode probe via SOCKS.
            val exitIp = fetchExitIp(viaProxy = mode != MODE_TUN)
            _state.value = VpnState.Connected(profile.name, exitIp)
        } catch (t: Throwable) {
            _state.value = VpnState.Error(t.message ?: "Не удалось подключиться")
            TunManager.stop()
            stopProcess()
        }
    }

    @Synchronized
    fun disconnect() {
        TunManager.stop()
        stopProcess()
        SystemProxy.disable()
        _state.value = VpnState.Disconnected
    }

    fun shutdown() {
        runCatching { TunManager.stop() }
        runCatching { stopProcess() }
        runCatching { SystemProxy.disable() }
    }

    /** xray output log for debugging (%APPDATA%/Vanna_vpn/xray.log). */
    fun logFile(): File {
        val base = System.getenv("APPDATA")?.let { File(it) }
            ?: File(System.getProperty("user.home"), ".config")
        return File(File(base, "Vanna_vpn").apply { mkdirs() }, "xray.log")
    }

    private fun waitPortOpen(port: Int, timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            try {
                Socket().use { it.connect(InetSocketAddress("127.0.0.1", port), 300); return true }
            } catch (_: Exception) {
                Thread.sleep(150)
            }
        }
        return false
    }

    /** HTTP probe through the SOCKS inbound; 2 attempts. */
    private fun testTunnel(): Boolean {
        val client = OkHttpClient.Builder()
            .proxy(Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", SOCKS_PORT)))
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .build()
        repeat(2) {
            runCatching {
                client.newCall(
                    Request.Builder().url("https://www.gstatic.com/generate_204").build()
                ).execute().use { resp ->
                    if (resp.code in 200..299 || resp.code == 204) return true
                }
            }
        }
        return false
    }

    /** Exit IP as seen through the tunnel — proves traffic really egresses via the server. */
    private fun fetchExitIp(viaProxy: Boolean): String? {
        val builder = OkHttpClient.Builder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(6, TimeUnit.SECONDS)
        if (viaProxy) {
            builder.proxy(Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", SOCKS_PORT)))
        } else {
            builder.proxy(Proxy.NO_PROXY)
        }
        val client = builder.build()
        return runCatching {
            client.newCall(Request.Builder().url("https://api.ipify.org").build())
                .execute().use { resp ->
                    if (resp.isSuccessful) resp.body?.string()?.trim()?.takeIf { it.isNotEmpty() }
                    else null
                }
        }.getOrNull()
    }

    private fun stopProcess() {
        process?.let { p ->
            runCatching {
                p.destroy()
                if (!p.waitFor(2, java.util.concurrent.TimeUnit.SECONDS)) p.destroyForcibly()
            }
        }
        process = null
    }
}
