package com.glassvpn.app.core

import com.sun.jna.Native
import com.sun.jna.Pointer
import com.sun.jna.win32.StdCallLibrary

/**
 * Windows system proxy toggle via HKCU registry (no admin rights required) +
 * WinINet refresh so running apps pick up the change without restart.
 */
object SystemProxy {

    private val isWindows = System.getProperty("os.name").lowercase().contains("win")

    private const val REG_KEY =
        "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings"

    private const val PROXY_OVERRIDE =
        "localhost;127.*;10.*;172.16.*;172.17.*;172.18.*;172.19.*;172.2*;172.30.*;172.31.*;192.168.*;<local>"

    fun enable(server: String) {
        if (!isWindows) return
        reg("ProxyEnable", "REG_DWORD", "1")
        reg("ProxyServer", "REG_SZ", server)
        reg("ProxyOverride", "REG_SZ", PROXY_OVERRIDE)
        refresh()
    }

    fun disable() {
        if (!isWindows) return
        reg("ProxyEnable", "REG_DWORD", "0")
        refresh()
    }

    private fun reg(name: String, type: String, value: String) {
        runCatching {
            ProcessBuilder("reg", "add", REG_KEY, "/v", name, "/t", type, "/d", value, "/f")
                .redirectErrorStream(true)
                .start()
                .waitFor()
        }
    }

    // INTERNET_OPTION_SETTINGS_CHANGED = 39, INTERNET_OPTION_REFRESH = 37
    private fun refresh() {
        runCatching {
            val wininet = Native.load("wininet", WinInet::class.java)
            wininet.InternetSetOptionA(null, 39, null, 0)
            wininet.InternetSetOptionA(null, 37, null, 0)
        }
    }

    @Suppress("FunctionName")
    private interface WinInet : StdCallLibrary {
        fun InternetSetOptionA(
            hInternet: Pointer?,
            dwOption: Int,
            lpBuffer: Pointer?,
            dwBufferLength: Int,
        ): Boolean
    }
}
