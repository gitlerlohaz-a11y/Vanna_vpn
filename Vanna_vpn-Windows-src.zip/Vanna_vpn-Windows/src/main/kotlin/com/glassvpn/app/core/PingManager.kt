package com.glassvpn.app.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.TimeUnit

/**
 * Real latency check: spawns a short-lived xray instance with a SOCKS inbound on a
 * free port and times an HTTP request through it. Returns -1 when unreachable.
 */
object PingManager {

    private const val TEST_URL = "https://www.gstatic.com/generate_204"
    private val semaphore = Semaphore(4)

    suspend fun measure(profile: ServerProfile): Long = withContext(Dispatchers.IO) {
        semaphore.withPermit { measureOnce(profile) }
    }

    private fun measureOnce(profile: ServerProfile): Long {
        val bin = XrayManager.xrayBinary()
        if (!bin.exists()) return -1L
        val port = freePort()
        val config = XrayConfigBuilder.build(
            profile,
            socksPort = port,
            httpPort = 0,
            routing = RoutingOptions(mode = RoutingOptions.MODE_GLOBAL),
        )
        val cfgFile = File.createTempFile("ping-", ".json").apply { writeText(config) }
        var proc: Process? = null
        return try {
            proc = ProcessBuilder(bin.absolutePath, "run", "-c", cfgFile.absolutePath)
                .directory(XrayManager.xrayDir())
                .redirectErrorStream(true)
                .start()
            // drain output so the process never blocks on a full pipe
            Thread { runCatching { proc.inputStream.readAllBytes() } }
                .apply { isDaemon = true }.start()
            if (!waitPortOpen(port, timeoutMs = 4000) || !proc.isAlive) return -1L

            val client = OkHttpClient.Builder()
                .proxy(Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", port)))
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                // keep one connection alive so the timed call reuses the warm tunnel
                .connectionPool(okhttp3.ConnectionPool(1, 30, TimeUnit.SECONDS))
                .build()

            // warm-up: pays the one-time TCP + TLS handshake cost (not counted),
            // matching how the mobile client measures latency on an open tunnel.
            val warm = runCatching {
                client.newCall(Request.Builder().url(TEST_URL).build()).execute()
                    .use { it.code in 200..299 || it.code == 204 }
            }.getOrDefault(false)
            if (!warm) return -1L

            // timed request reuses the kept-alive connection → pure round-trip latency
            val started = System.nanoTime()
            client.newCall(Request.Builder().url(TEST_URL).build()).execute().use { resp ->
                if (resp.code in 200..299 || resp.code == 204) {
                    (System.nanoTime() - started) / 1_000_000
                } else -1L
            }
        } catch (_: Throwable) {
            -1L
        } finally {
            runCatching {
                proc?.destroy()
                if (proc?.waitFor(1, TimeUnit.SECONDS) == false) proc.destroyForcibly()
            }
            cfgFile.delete()
        }
    }

    private fun freePort(): Int = ServerSocket(0).use { it.localPort }

    private fun waitPortOpen(port: Int, timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            try {
                Socket().use { s ->
                    s.connect(InetSocketAddress("127.0.0.1", port), 250)
                    return true
                }
            } catch (_: Throwable) {
                Thread.sleep(120)
            }
        }
        return false
    }
}
