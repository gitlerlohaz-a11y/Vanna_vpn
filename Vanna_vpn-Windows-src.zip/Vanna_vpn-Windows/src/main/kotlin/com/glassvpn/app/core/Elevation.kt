package com.glassvpn.app.core

import java.io.File
import kotlin.system.exitProcess

/**
 * Admin-rights helpers for the Windows TUN mode: `net session` succeeds only in an
 * elevated process; relaunch goes through PowerShell `Start-Process -Verb RunAs`
 * so the user gets the standard UAC prompt.
 */
object Elevation {

    private val isWindows = System.getProperty("os.name").lowercase().contains("win")

    fun isAdmin(): Boolean {
        if (!isWindows) return true
        return runCatching {
            val p = ProcessBuilder("net", "session")
                .redirectErrorStream(true)
                .start()
            p.inputStream.readAllBytes()
            p.waitFor() == 0
        }.getOrDefault(false)
    }

    /** Relaunches the app elevated (UAC prompt) and terminates the current instance. */
    fun relaunchAsAdmin() {
        if (!isWindows) return
        val javaw = File(System.getProperty("java.home"), "bin\\javaw.exe").absolutePath
        val appDir = XrayManager.appDir().absolutePath
        val jar = File(XrayManager.appDir(), "app\\Vanna_vpn.jar").absolutePath
        // PowerShell single-quoted strings; embedded double quotes protect paths with spaces.
        val argList = "-Dapp.dir=\"$appDir\" -jar \"$jar\""
        val command =
            "Start-Process -FilePath '$javaw' -ArgumentList '$argList' -Verb RunAs"
        runCatching {
            ProcessBuilder("powershell", "-NoProfile", "-Command", command).start()
        }.onSuccess {
            XrayManager.shutdown()
            exitProcess(0)
        }
    }
}
