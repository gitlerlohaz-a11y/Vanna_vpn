package com.glassvpn.app.core

import java.io.File
import java.net.InetAddress
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.TimeUnit

/**
 * Windows TUN mode (v2rayN-style): tun2socks creates a wintun adapter and forwards
 * everything to xray's local SOCKS inbound; /1 routes override the default route
 * without deleting it, and a /32 host route keeps the VPN server reachable directly.
 * Requires an elevated process.
 */
object TunManager {

    private const val TUN_DEVICE = "wintun" // adapter name created by tun2socks
    private const val TUN_IP = "192.168.123.1"
    private const val TUN_MASK = "255.255.255.0"
    private const val DNS = "8.8.8.8"

    private var process: Process? = null
    private var serverIp: String? = null
    private val recentLog = ConcurrentLinkedDeque<String>()

    fun tun2socksBinary(): File = File(XrayManager.xrayDir(), "tun2socks.exe")

    /** tun2socks output log (%APPDATA%/Vanna_vpn/tun2socks.log). */
    fun logFile(): File = File(XrayManager.logFile().parentFile, "tun2socks.log")

    private fun logTail(): String =
        recentLog.lastOrNull { it.contains("error", true) || it.contains("failed", true) }
            ?: recentLog.lastOrNull().orEmpty()

    /** Starts the TUN pipeline. Returns null on success or a user-facing error message. */
    @Synchronized
    fun start(serverHost: String, socksPort: Int): String? {
        stop()
        val bin = tun2socksBinary()
        if (!bin.exists()) return "Не найден tun2socks.exe рядом с приложением"

        val ip = runCatching { InetAddress.getByName(serverHost).hostAddress }.getOrNull()
            ?: return "Не удалось определить IP сервера $serverHost"
        serverIp = ip

        val gateway = defaultGateway()
            ?: return "Не удалось определить шлюз по умолчанию"

        recentLog.clear()
        val log = logFile().apply { runCatching { writeText("") } }
        val proc = runCatching {
            ProcessBuilder(
                bin.absolutePath,
                "-device", TUN_DEVICE,
                "-proxy", "socks5://127.0.0.1:$socksPort",
                "-loglevel", "info",
            )
                .directory(XrayManager.xrayDir())
                .redirectErrorStream(true)
                .start()
        }.getOrElse { return "Не удалось запустить tun2socks: ${it.message}" }
        process = proc
        Thread {
            runCatching {
                proc.inputStream.bufferedReader().forEachLine { line ->
                    recentLog.addLast(line)
                    while (recentLog.size > 40) recentLog.pollFirst()
                    runCatching { log.appendText(line + "\n") }
                }
            }
        }.apply { isDaemon = true }.start()

        // wait for the wintun adapter to appear
        if (!waitAdapter(timeoutMs = 15000) || !proc.isAlive) {
            val tail = logTail()
            stop()
            return if (proc.isAlive) {
                ("TUN-адаптер не появился. " + tail).trim().take(260)
            } else {
                ("tun2socks завершился (антивирус мог заблокировать wintun.dll). " + tail)
                    .trim().take(260)
            }
        }

        // assign the tunnel IP first
        val addrCode = run(
            listOf(
                "netsh", "interface", "ipv4", "set", "address",
                "name=$TUN_DEVICE", "source=static", "addr=$TUN_IP", "mask=$TUN_MASK",
            )
        )
        if (addrCode != 0) {
            stop()
            return "Не удалось задать IP TUN-адаптера (код $addrCode). Запусти от администратора"
        }

        // CRITICAL: wait until the adapter actually has the IP, otherwise the
        // route commands below run against an interface that isn't ready and fail
        // silently — which is exactly "connected but traffic still goes direct".
        val ifIndex = waitInterfaceReady(timeoutMs = 8000)
            ?: run { stop(); return "TUN-адаптер не получил IP. Запусти от администратора" }
        log.appendText("[setup] wintun ready, ifIndex=$ifIndex\n")

        run(
            listOf(
                "netsh", "interface", "ipv4", "set", "dnsservers",
                "name=$TUN_DEVICE", "static", "address=$DNS", "register=none", "validate=no",
            )
        )
        // prefer the tunnel interface
        run(listOf("netsh", "interface", "ipv4", "set", "interface", ifIndex, "metric=1"))

        // keep the VPN server reachable via the real gateway (so the tunnel itself
        // doesn't get routed into itself)
        run(listOf("route", "delete", ip))
        run(listOf("route", "add", ip, "mask", "255.255.255.255", gateway, "metric", "5"))

        // /1 + /1 beats the /0 default route without deleting it. Pin them to the
        // wintun interface index and verify they actually land in the table.
        val routeCmds = listOf(
            listOf("route", "add", "0.0.0.0", "mask", "128.0.0.0", TUN_IP, "metric", "1", "if", ifIndex),
            listOf("route", "add", "128.0.0.0", "mask", "128.0.0.0", TUN_IP, "metric", "1", "if", ifIndex),
        )
        for (cmd in routeCmds) {
            var ok = false
            repeat(3) { attempt ->
                if (!ok) {
                    val code = run(cmd)
                    log.appendText("[setup] ${cmd.joinToString(" ")} -> $code\n")
                    if (code == 0) ok = true else Thread.sleep(400)
                }
            }
            if (!ok) {
                stop()
                return "Не удалось добавить маршрут в TUN (нужны права администратора)"
            }
        }

        // sanity-check: the default-split routes must be present and pointing at the tunnel
        if (!routesPresent()) {
            stop()
            return "Маршруты TUN не применились. Запусти приложение от администратора"
        }
        log.appendText("[setup] routes applied OK\n")
        return null
    }

    @Synchronized
    fun stop() {
        runCatching { run(listOf("route", "delete", "0.0.0.0", "mask", "128.0.0.0", TUN_IP)) }
        runCatching { run(listOf("route", "delete", "128.0.0.0", "mask", "128.0.0.0", TUN_IP)) }
        serverIp?.let { runCatching { run(listOf("route", "delete", it)) } }
        serverIp = null
        process?.let { p ->
            runCatching {
                p.destroy()
                if (!p.waitFor(2, TimeUnit.SECONDS)) p.destroyForcibly()
            }
        }
        process = null
    }

    val isActive: Boolean get() = process?.isAlive == true

    private fun run(cmd: List<String>): Int = runCatching {
        val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
        p.inputStream.readAllBytes()
        p.waitFor()
    }.getOrDefault(-1)

    private fun waitAdapter(timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (process?.isAlive != true) return false
            val netsh = runCatching {
                val p = ProcessBuilder("netsh", "interface", "show", "interface")
                    .redirectErrorStream(true).start()
                String(p.inputStream.readAllBytes()).also { p.waitFor() }
            }.getOrDefault("")
            if (netsh.contains(TUN_DEVICE, ignoreCase = true)) return true
            val ps = runCatching {
                val p = ProcessBuilder(
                    "powershell", "-NoProfile", "-Command",
                    "(Get-NetAdapter -Name '$TUN_DEVICE' -ErrorAction SilentlyContinue).Name",
                ).redirectErrorStream(true).start()
                String(p.inputStream.readAllBytes()).trim().also { p.waitFor() }
            }.getOrDefault("")
            if (ps.equals(TUN_DEVICE, ignoreCase = true)) return true
            Thread.sleep(400)
        }
        return false
    }

    /**
     * Waits until the wintun adapter is up AND has its IPv4 address assigned,
     * returning its interface index (as a string for `route ... if N`).
     */
    private fun waitInterfaceReady(timeoutMs: Long): String? {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val idx = runCatching {
                val p = ProcessBuilder(
                    "powershell", "-NoProfile", "-Command",
                    "\$a=Get-NetIPAddress -InterfaceAlias '$TUN_DEVICE' -AddressFamily IPv4 " +
                        "-ErrorAction SilentlyContinue | Where-Object {\$_.IPAddress -eq '$TUN_IP'}; " +
                        "if(\$a){\$a.InterfaceIndex}",
                ).redirectErrorStream(true).start()
                String(p.inputStream.readAllBytes()).trim().also { p.waitFor() }
            }.getOrDefault("")
            if (idx.matches(Regex("""\d+"""))) return idx
            Thread.sleep(400)
        }
        return null
    }

    /** True when the /1 split routes are present in the routing table on the tunnel. */
    private fun routesPresent(): Boolean {
        val out = runCatching {
            val p = ProcessBuilder("route", "print", "-4")
                .redirectErrorStream(true).start()
            String(p.inputStream.readAllBytes()).also { p.waitFor() }
        }.getOrDefault("")
        return out.contains("0.0.0.0          128.0.0.0          $TUN_IP") ||
            Regex("""0\.0\.0\.0\s+128\.0\.0\.0\s+$TUN_IP""").containsMatchIn(out)
    }

    /** Next hop of the current 0.0.0.0/0 route (lowest metric). */
    private fun defaultGateway(): String? {
        val ps = runCatching {
            val p = ProcessBuilder(
                "powershell", "-NoProfile", "-Command",
                "(Get-NetRoute -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue | " +
                    "Where-Object {\$_.NextHop -ne '0.0.0.0'} | " +
                    "Sort-Object -Property RouteMetric | Select-Object -First 1).NextHop",
            ).redirectErrorStream(true).start()
            String(p.inputStream.readAllBytes()).trim().also { p.waitFor() }
        }.getOrDefault("")
        if (ps.matches(Regex("""\d+\.\d+\.\d+\.\d+"""))) return ps

        // fallback: parse `route print 0.0.0.0`
        val out = runCatching {
            val p = ProcessBuilder("route", "print", "0.0.0.0")
                .redirectErrorStream(true).start()
            String(p.inputStream.readAllBytes()).also { p.waitFor() }
        }.getOrDefault("")
        return Regex("""0\.0\.0\.0\s+0\.0\.0\.0\s+(\d+\.\d+\.\d+\.\d+)""")
            .find(out)?.groupValues?.get(1)
    }
}
